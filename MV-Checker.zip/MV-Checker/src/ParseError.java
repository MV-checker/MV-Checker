
public class ParseError extends Exception {
    public ParseError(String error) {
        super(error);
    }

}
