import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


public interface Accessibility {

    public String getSourceAgent();
    public String getSourceState();
    public String getTargetAgent();
    public String getTargetState();
    public Type getType();

    public static List<String> getGroup(String fraction){
        String input = "{i,j,k}";
        String pattern = "\\{(.+)}";
        List<String> agents = Arrays.stream(fraction.replaceAll(pattern, "$1").split(",")).collect(Collectors.toList());
        return agents;
    }

    public enum Type{
        REGULAR_ACCESSIBILITY,
        EVERYONE_ACCESSIBILITY,
        DISTRIBUTED_ACCESSIBILITY,
        PROPAGATED_ACCESSIBILITY,
    }
}
