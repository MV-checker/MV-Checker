
public class Token 
{
	public static final int EPSILON = 0;
	public static final int O_BRACE = 1;
	public static final int C_BRACE = 2;
	public static final int O_BRACKET = 3;
	public static final int C_BRACKET = 4;
	public static final int COMMA = 5;
	public static final int SEMICOLON = 6;
	public static final int EQUAL = 7;
	public static final int COLON = 8;
	public static final int SYNTAX = 9;
	public static final int VARIABLE = 10;
	public static final int AGENT = 11;
	public static final int EVALUATION = 12;
	public static final int EVALUATIONT = 17;
	public static final int INIT = 13;
	public static final int FORMULAE = 14;
	public static final int END = 15;
	public static final int ENDT = 18;
	public static final int ESCAPE = 16;
	
	public final int token;
	public final String sequence;
	
	public Token(int token, String content)
	{
		this.token = token;
		sequence = content;
		//System.out.println(token);
		//System.out.println(content);
	}
	

}
