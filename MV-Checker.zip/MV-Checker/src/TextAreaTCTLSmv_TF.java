
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.text.DecimalFormat;

import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import javax.swing.WindowConstants;
import java.io.FileWriter;




public class TextAreaTCTLSmv_TF extends JFrame { 
	
 // protected static final String newFile = null;
private JScrollPane jScrollPane;
  private JTextArea textarea ; 
  private  JButton generateSMVButton;
 // private TextArea txt;
 // JPanel content;
  private final JPanel content;
  //private final TextArea txt;
  
 
    
public TextAreaTCTLSmv_TF(String newFile) throws IOException {	   
	setLocation(50, 30);
	textarea =new JTextArea(30, 60); 	
	textarea.setText(newFile);
    textarea.setVisible(true);
	setLayout(new FlowLayout());
    add(new JScrollPane(textarea));
    Color col =new Color(98,100,163);
    getContentPane().setBackground(col);
    
    
content = (JPanel) this.getContentPane();
File file  = new File(newFile);
FileWriter writer1 = null;
try {
	writer1 = new FileWriter("c:/TCTLmodel.txt");
} catch (IOException e3) {
	// TODO Auto-generated catch block
	e3.printStackTrace();
}

    writer1.write(newFile);
     writer1.close(); 
    
  //  txt = new TextArea();
  //  txt.setBounds(25, 100, 600, 580);
  //  txt.setMaximumSize(new Dimension(600, 580));
  ////  txt.setPreferredSize(new Dimension(600, 580));
  //  txt.setMaximumSize(new Dimension(800, 980));
  //  txt.setEditable(false);
  //  content.add(txt);
     
	  	
	
jScrollPane = new JScrollPane(this.textarea);
     this.add(this.jScrollPane);
      this.setVisible(true);
      this.setSize(700, 600);
      this.setTitle("TCTL model with TT and TF as True");
      
      //////////////
      generateSMVButton = new JButton("Generate SMV model");
      generateSMVButton.setBounds(450, 10, 180, 30);
       
      content.add(generateSMVButton);
       
      generateSMVButton.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
          	
          	
              if (newFile == null || textarea.getText().length()==0){
                  throwErrorDialogue("Please load a BT Model before trying to generate an SMV model.","Illegal Action");
              }
              else{
                  try {
                	//  File file  = new File(newFile);
                  	ISPLInputResource input = new ISPLInputResource("c:/TCTLmodel.txt");
                      input.removeWhiteSpace();
                      ISPLtoSMVTranslatorTF parser = new ISPLtoSMVTranslatorTF();
                      double starter = System.nanoTime();
                      parser.parse(parser.construct(input.getTokens()));
                      double finalist = System.nanoTime();
                      double cst = 1000000;
                      double tt = parser.getFormulaTotal();
                      double res = (finalist - starter) / cst; 
                   
                      nusmv1 f = new nusmv1(parser.yieldResult(), res - tt, parser.getFormulaTotal(), parser.formulaTimeTable);
                      f.setVisible(true);
                     
                  } catch (ParseError e1) {
                      JOptionPane
                              .showMessageDialog(
                                      new JFrame(), e1.getMessage(),
                                      "Parser Error"
                                      , JOptionPane.ERROR_MESSAGE);
                  } catch (FormulaeTransfomer.ParenthesisException e2) {
                      JOptionPane
                              .showMessageDialog(
                                      new JFrame(), e2.getMessage(),
                                      "Formulae correctness Parser Error"
                                      , JOptionPane.ERROR_MESSAGE);
                  }
              }
          }

          

      });
      getContentPane().add(generateSMVButton);


      }
 
private static void throwErrorDialogue(String errorMessage, String typeOfError) {
    JOptionPane.showMessageDialog(new JFrame(), errorMessage, typeOfError, JOptionPane.ERROR_MESSAGE);
}	  
/////////////////////////

	


@SuppressWarnings("serial")
static class nusmv1 extends JFrame implements ActionListener {

     
	static String modelOutput = "";
    static String modelFileSaved = "C:\\JTL\\scal.out";

    long formulae, starts, ends;
    double mo, fo;
    static double[] formulaTable;

    @SuppressWarnings("static-access")
    public nusmv1(String h, double m, double f, double[] formulaTimeTable) {
        this.setName("NuSMV Launch Interface");
        initComponents();
        jTextArea1.setText(h);
        mo = m;
        fo = f;
        if (formulaTimeTable != null) {
            this.formulaTable = formulaTimeTable;
            formulae = 0;
            for (int i = 0; i < formulaTimeTable.length; ++i) {
                formulae += formulaTimeTable[i];
            }
        }

    }


    private void initComponents() {
    	Color col =new Color(120,138,199);
        getContentPane().setBackground(col);
        setLocation(0, 0);
        jPanel1 = new JPanel();
        jScrollPane1 = new JScrollPane();
        jTextArea1 = new JTextArea();
        launchNuSMVButton = new JButton();
        jPanel2 = new JPanel();
        jScrollPane2 = new JScrollPane();
        jTextArea2 = new JTextArea();
        jLabel1 = new JLabel();
        jTextField1 = new JTextField();
        jLabel2 = new JLabel();
        jTextField2 = new JTextField();
        jLabel3 = new JLabel();
        jTextField3 = new JTextField();
        jTextField4 = new JTextField();
        jLabel4 = new JLabel();
        timeFormulaButton = new JButton();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        jScrollPane1.setBorder(BorderFactory.createTitledBorder("CTL Model "));
        Color col1 =new Color(202, 206, 233);
        jPanel1.setBackground(col1);
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jScrollPane1.setViewportView(jTextArea1);
        jTextArea1.getAccessibleContext().setAccessibleName("");

        launchNuSMVButton.setText("Launch NuSMV");

        jPanel2.setBorder(BorderFactory.createTitledBorder("Verification Results"));

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        GroupLayout jPanel2Layout = new GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane2)
                                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane2, GroupLayout.DEFAULT_SIZE, 299, Short.MAX_VALUE)
                                .addContainerGap())
        );

        jLabel1.setText("Time of Transofrming Model");

        jTextField1.setText("0ms");

        jLabel2.setText("Total Time of Transforming Formulas");

        jTextField2.setText("0ms");

        jLabel3.setText("Time of Verification Process");

        jTextField3.setText("0ms");

        jTextField4.setText("0ms");

        jLabel4.setText("Total Time");

        timeFormulaButton.setForeground(new Color(0, 102, 255));
        timeFormulaButton.setText("Time/Formula");
        timeFormulaButton.setBorder(null);

        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 490, GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(launchNuSMVButton)
                                                .addGap(0, 0, Short.MAX_VALUE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jPanel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addContainerGap())
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                                                        .addGroup(GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                                .addComponent(jLabel4)
                                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                .addComponent(jTextField4, GroupLayout.PREFERRED_SIZE, 186, GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                                        .addComponent(jLabel1)
                                                                        .addComponent(jLabel3)
                                                                        .addComponent(jLabel2))
                                                                .addGap(25, 25, 25)
                                                                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                                        .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
                                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                .addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
                                                                                .addGap(18, 18, 18)
                                                                                .addComponent(timeFormulaButton)))))
                                                .addGap(49, 49, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(launchNuSMVButton)
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jPanel2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jLabel1)
                                                        .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                .addGap(9, 9, 9)
                                                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jLabel2)
                                                        .addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(timeFormulaButton))
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jLabel3)
                                                        .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                .addGap(18, 18, Short.MAX_VALUE)
                                                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jTextField4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel4)))
                                        .addComponent(jScrollPane1))
                                .addContainerGap())
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );

        jPanel1.getAccessibleContext().setAccessibleName("CTL Model");

        launchNuSMVButton.addActionListener(this);
        timeFormulaButton.addActionListener(this);
        pack();
    }// </editor-fold>

    private void runScalableModel() {
        // save file to run with NuSMV
        saveGeneratedFile();
        starts = System.nanoTime();
        try {
            modelOutput = NuSMVInteractor2.runNuSMVModel();
        } catch (IOException e) {
            JOptionPane
                    .showMessageDialog(
                            new JFrame(),
                            "The tool couldn't access files on the system, Please verify its running with admin privileges",
                            "File System Access Denied", JOptionPane.ERROR_MESSAGE);
        } finally {
            ends = System.nanoTime();
        }
        DecimalFormat formatter = new DecimalFormat("#00.000000");
        double process = (ends - starts) / (double) (cst);
        jTextField1.setText("" + formatter.format(mo) + "ms");
        jTextField2.setText("" + formatter.format(fo) + "ms");
        jTextField3.setText("" + formatter.format(process) + "ms");
        jTextField4.setText("" + formatter.format(mo + fo + process) + "ms");
        jTextArea2.setText(modelOutput);
    }

    private JButton launchNuSMVButton;
    private JButton timeFormulaButton;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JPanel jPanel1;
    private JPanel jPanel2;
    private JScrollPane jScrollPane1;
    private JScrollPane jScrollPane2;
    private JTextArea jTextArea1;
    private JTextArea jTextArea2;
    private JTextField jTextField1;
    private JTextField jTextField2;
    private JTextField jTextField3;
    private JTextField jTextField4;
    static double cst = 10000000;
    public void saveGeneratedFile() {
        File file = new File(modelFileSaved);
        Writer output = null;
        try {
            output = new BufferedWriter(new FileWriter(file));
            output.write(jTextArea1.getText());
            output.close();
        } catch (IOException e) {
            //e.printStackTrace();
            JOptionPane
                    .showMessageDialog(
                            new JFrame(),
                            "The tool couldn't access files on the system, Please verify its running with admin priveleges",
                            "File System Access Denied", JOptionPane.ERROR_MESSAGE);
        }
    }


    @Override
    public void actionPerformed(ActionEvent arg0) {

        if (arg0.getSource() == launchNuSMVButton) {
            runScalableModel();
        } else if (arg0.getSource() == timeFormulaButton) {
            JComponent[] input = new JComponent[2 * formulaTable.length];
            for (int i = 0; i < formulaTable.length; ++i) {
                JLabel lab = new JLabel("Formula " + (i + 1));
                JLabel labs = new JLabel(formulaTable[i] + "ms");
                input[2 * i] = lab;
                input[2 * i + 1] = labs;
            }
            @SuppressWarnings("unused")
            int result = JOptionPane.showConfirmDialog(null, input, "Time/Formula", JOptionPane.PLAIN_MESSAGE);
        }

    }
}


/////////////////////////////
public static void main(String[] args) {
  String String = null;
  }	
//public static void 
//setFrame(final JFrame frame, final int width, final int height) {
//  SwingUtilities.invokeLater(new Runnable() {
 //   public void run() {
//frame.setTitle("CTL");
//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//frame.setSize(900, 800);
//frame.setVisible(true);
//   }
//   });
 }

//} 