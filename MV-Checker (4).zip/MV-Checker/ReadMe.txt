
To run MV-checker for interacting with MCMAS versions, please follow the next steps:
1- Install MCMAS+.exe/MCMASt.exe.
2- Put the executable file in the bin folder of Cygwin.
3- Run the jar file (MV-Cheker.jar).
4- Upload the mv-ISPL file of the mv-model that needed to be verified. The file is located in "MV-Checker/mcmas-Exp"
5- Generate the corresponding classical models by pressing the corresponding buttons.
6- Press the "Launch MCMAS" button to get the verification result of each file.

To run MV-checker for interacting with NuSMV, please follow the next steps:
1- Install NuSMV.
2- Run the jar file (MV-Cheker.jar).
3- Press the " MV-CTLC to CTL" or  " MV-TCTL to CTL" button.
4- Upload the mv-ISPL file of the mv-model that needed to be verified. The file is located in "MV-Checker/NuSMV-Exp"
5- Press the corresponding buttons to generate the corresponding classical trust or commitment models.
6- Press the " Generate the SMV model" button   to transform the obtained classical trust/commitment models and formula to CTL.
7- Press the "Launch NuSMV " button over each CTL model to get the verification results.


