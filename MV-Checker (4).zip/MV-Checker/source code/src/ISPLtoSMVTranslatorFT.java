
 

import java.util.*;

public class ISPLtoSMVTranslatorFT {
    LinkedList<Token> tokens;
    String ready;
    Token lookahead;
    String prop;
    StringBuilder finalSMV;
    StringBuilder formulae;
    Vector<String> smv;
    Vector<String> agents;
    List<Agent> GlobalAgents;
    Vector<Module> modules;
    Set<String> acc;
    GlobalSystem system;
    double[] formulaTimeTable;

    int ModCount;
    double form = 0;

    double getFormulaTotal() {
        return form;
    }

    public ISPLtoSMVTranslatorFT() {
        finalSMV = new StringBuilder();
        formulae = new StringBuilder();
        smv = new Vector<String>();
        agents = new Vector<String>();
        modules = new Vector<Module>();
        GlobalAgents = new ArrayList<Agent>();
        acc = new TreeSet<String>();
        system = new GlobalSystem();
        ModCount = 0;
        prop = "";
    }

    public void printFormulaes() {
        System.out.println(formulae.toString());
    }

    public LinkedList<Token> construct(LinkedList<String> data) {
        LinkedList<Token> res = new LinkedList<Token>();
        for (String t : data) {
            t = t.trim();
            // depending on the type, create the Token, and add it to the list
            if (t.equals("(")) {
                Token n = new Token(Token.O_BRACE, t);
                res.add(n);
            } else if (t.equals(")")) {
                Token n = new Token(Token.C_BRACE, t);
                res.add(n);
            } else if (t.equals("{")) {
                Token n = new Token(Token.O_BRACKET, t);
                res.add(n);
            } else if (t.equals("}")) {
                Token n = new Token(Token.C_BRACKET, t);
                res.add(n);
            } else if (t.equals(",")) {
                Token n = new Token(Token.COMMA, t);
                res.add(n);
            } else if (t.equals(";")) {
                Token n = new Token(Token.SEMICOLON, t);
                res.add(n);
            } else if (t.equals("=")) {
                Token n = new Token(Token.EQUAL, t);
                res.add(n);
            } else if (t.equals(":")) {
                Token n = new Token(Token.COLON, t);
                res.add(n);
            } else if (t.equals("Agent")) {
                Token n = new Token(Token.AGENT, t);
                res.add(n);
            } else if (t.equals("Evaluation")) {
                Token n = new Token(Token.EVALUATION, t);
                res.add(n);
            } else if (t.equals("InitStates")) {
                Token n = new Token(Token.INIT, t);
                res.add(n);
            } else if (t.equals("Formulae")) {
                Token n = new Token(Token.FORMULAE, t);
                res.add(n);
            } else if (t.equals("end")) {
                Token n = new Token(Token.END, t);
                res.add(n);
            } else if (t.equals("and") || t.equals("if") || t.equals("or") || t.equals("Vars") || t.equals("Actions") || t.equals("Other")
                    || t.equals("Protocol") || t.equals("Evolution"))// syntax
            {
                Token n = new Token(Token.SYNTAX, t);
                res.add(n);
            } else if (t.contains("--")) {
                Token n = new Token(Token.ESCAPE, t);
                res.add(n);
            } else // the rest is a variable
            {
                Token n = new Token(Token.VARIABLE, t);
                res.add(n);
            }

        }
        return res;
    }

    public void print(LinkedList<Token> tokens) {
        for (Token t : tokens) {
            System.out.println(t.token + " : " + t.sequence);
        }
    }

    public void printTokens() {
        for (Token t : tokens) {
            System.out.println(t.token + " : " + t.sequence);
        }
    }

    @SuppressWarnings("unchecked")
    public void parse(LinkedList<Token> tokens) throws ParseError, FormulaeTransfomer.ParenthesisException {
        this.tokens = (LinkedList<Token>) tokens.clone();
        lookahead = this.tokens.getFirst();

        // call for the general expression parsing function
        Expression();
        if (lookahead.token != Token.EPSILON) {
            printTokens();
            throw new ParseError("Unexpected symbol '" + lookahead.sequence + "' found");
        }
        system = new GlobalSystem();
        system.setAgents(GlobalAgents);

        generateSMV();
    }

    private Module getModuleByName(String name) {
        for (Module m : modules) {
            if (m.getName().equals(name)) {
                return m;
            }
        }
        return null;
    }

    // decide which heuristic to use for accessibility if needed based on pre-calculated bit mask stored in array of chars
    // the bit mask is used to store the states of the dynamic programming recursion calls
    private void symbolicExecution() {
        if (modules.stream().filter(t -> t.Name.contains(HashingData.decodeFromBits(bc))).count() != 0) {
            acc = system.HeursticGuidedUCSearch(acc, modules.size());
        }
        if (modules.stream().filter(t -> t.Name.contains(HashingData.decodeFromBits(bs))).count() != 0) {
            acc = system.HeuristicGuidedAStarSearch(acc, modules.size());
        }
    }

    private void manageDependenciesAbreviations() {
        for (Module m : modules) {
            for (String mod : m.other) {
                String abrev = getCorespAbrev(mod);
                m.otherAbrev.add(abrev);
            }
        }
    }

    private void generateSMV() throws FormulaeTransfomer.ParenthesisException {

        finalSMV = new StringBuilder();
        finalSMV.append("MODULE main \n");
        finalSMV.append("VAR \n");
        manageDependenciesAbreviations();
        for (Module m : modules) {
            for (Module n : modules) {
                if (!n.getName().equals(m.getName()) && n.other.contains(m.Name)) {
                    m.other.add(n.getName());
                    m.otherAbrev.add(n.getAbrev());
                    m.findShared(n);
                }
            }
        }
        for (Module m : modules) {
            finalSMV.append(m.getAbrev() + " : " + m.getName() + " ( " + m.getOther());
        }
        // start atomic props
        finalSMV.append("\n-- Atomic Propositions \n\n");
        symbolicExecution();
        finalSMV.append(prop + "\n");
        for (String s : acc) {
            finalSMV.append(s + "\n");
        }
        finalSMV.append("-- Forumlae\n");
        String[] fs = formulae.toString().split(";\n");
        formulaTimeTable = new double[fs.length];
        int i = 0;
        FormulaeTransfomer engine = new BranchingTrustToSMV();
        for (String one : fs) {
            if (one.trim() != "") {
                double cst = 1000000;
                double start = System.nanoTime();
//				finalSMV.append(action(one)+"\n");
                finalSMV.append(engine.parse(one) + "\n");
                double finals = System.nanoTime();
                form = form + (finals - start) / cst;
                //System.out.println("formula "+i+" "+(finals-start)/cst + "ms");
                formulaTimeTable[i] = (finals - start) / cst;
                i++;
            }
        }
        for (Module m : modules) {

            finalSMV.append("\n\n-- Definition of " + m.getName() + "  \n\n\n");
            finalSMV.append("MODULE " + m.getName() + " ( ");
            finalSMV.append(m.getOthers());
            m.setup();
            finalSMV.append("\nVAR state : {" + m.getVars());
            finalSMV.append("IVAR action : {" + m.getActions());
            finalSMV.append("INIT (state = " + m.init + ")\n");
            finalSMV.append(m.getEval());

        }

        ready = finalSMV.toString();
        // System.out.println(ready);
    }

    public void printAll() {
        System.out.println(ready);
    }

    public String yieldResult() {
        return ready;
    }

    public String getAll() {
        return ready;
    }

    private void nextToken() {
        tokens.pop();
        if (tokens.isEmpty()) {
            lookahead = new Token(Token.EPSILON, "");
        } else {
            lookahead = tokens.getFirst();
            if (lookahead.token == Token.ESCAPE) {
                tokens.pop();
                lookahead = tokens.getFirst();
            }
        }
    }

    private void Expression() throws ParseError {
        if (lookahead.token == Token.AGENT) {
            Agent();
        } else if (lookahead.token == Token.EVALUATION) {
            Propositions();
        } else if (lookahead.token == Token.INIT) {
            init();
        } else if (lookahead.token == Token.FORMULAE) {
            Formulae();
        }
    }

    private void Agent() throws ParseError {
        finalSMV = new StringBuilder();
        nextToken();
        // get Agent name
        agents.add(lookahead.sequence);
        Module mod = new Module();
        Agent tempAgent = new Agent();
        mod.setName(lookahead.sequence);
        tempAgent.setName(lookahead.sequence);
        mod.setI(ModCount);
        tempAgent.setAbbrev(mod.abrev);
        ModCount++;
        modules.add(mod);
        GlobalAgents.add(tempAgent);
        // finalSMV.append("");
        nextToken();
        // VAR
        Var();
        // Actions
        Actions();
        // Protocol
        Protocol();
        // Evolution
        Evolution();
        // verify end
        if (lookahead.token != Token.END) {
            throw new ParseError("ISPL Syntax Error : Expected 'end' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        // verify agent
        if (lookahead.token != Token.AGENT) {
            throw new ParseError("ISPL Syntax Error : Expected 'Agent' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        Agent temp = GlobalAgents.get(ModCount - 1);
        temp.getData(modules.get(ModCount - 1));
        Expression();
    }

    private void Var() throws ParseError {

        if (!lookahead.sequence.equals("Vars")) {
            throw new ParseError("ISPL Syntax Error : Expected 'Vars' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();

        if (lookahead.token != Token.COLON) {
            throw new ParseError("ISPL Syntax Error : Expected ':' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        // multiple lines of definitions
        // then end of var
        while (lookahead.token != Token.END) {
            varLine();
        }
        nextToken();

        if (!lookahead.sequence.equals("Vars")) {
            throw new ParseError("ISPL Syntax Error : Expected 'Vars' but found '" + lookahead.sequence + "' instead");
        }

        // mod now has all variables. we should just put it all in agent
        nextToken();
    }

    private void varLine() throws ParseError {
        // pr: {p0,p1,p2,p3,p4};
        //nextToken();
        // get var name
//		System.out.println("should be empty here : "+finalSMV);
        finalSMV.append(lookahead.sequence);
        //System.out.println("This is new : "+finalSMV);
        nextToken();
        // get Colon
        if (lookahead.token != Token.COLON) {
            throw new ParseError("ISPL Syntax Error : Expected ':' but found '" + lookahead.sequence + "' instead");
        }

        nextToken();
        // get Open bracket

        if (lookahead.token != Token.O_BRACKET) {
            throw new ParseError("ISPL Syntax Error : Expected '{' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        // read data
        finalSMV.append(" " + lookahead.sequence);
        nextToken();// this one is the first value !
        //finalSMV.append(" "+lookahead.sequence);

        while (lookahead.token != Token.C_BRACKET) {

            // verify its a comma
            if (lookahead.token != Token.COMMA) {
                throw new ParseError("ISPL Syntax Error : Expected ',' but found '" + lookahead.sequence + "' instead");
            }
            nextToken();
            // get Data
            finalSMV.append(" " + lookahead.sequence);
            nextToken();
        }
        nextToken();
        if (lookahead.token != Token.SEMICOLON) {
            throw new ParseError("ISPL Syntax Error : Expected ';' but found '" + lookahead.sequence + "' instead");
        }
        Module mod = modules.get(ModCount - 1);
        mod.addVar(finalSMV.toString());
//		System.out.println("Module "+mod.getName()+"has this shared sequence"+finalSMV.toString());
        finalSMV = new StringBuilder();
        nextToken();
    }

    private void Actions() throws ParseError {// { data , data } or , and data

        if (!lookahead.sequence.equals("Actions")) {
            throw new ParseError(
                    "ISPL Syntax Error : Expected 'Actions' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();

        if (lookahead.token != Token.EQUAL) {
            throw new ParseError("ISPL Syntax Error : Expected '=' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();

        if (lookahead.token != Token.O_BRACKET) {
            throw new ParseError("ISPL Syntax Error : Expected '{' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        // get first action data
        Module mod = modules.get(ModCount - 1);
        mod.addAction(lookahead.sequence);
        nextToken();
        while (lookahead.token != Token.C_BRACKET) {
            // verify comma

            if (lookahead.token != Token.COMMA) {
                throw new ParseError("ISPL Syntax Error : Expected ',' but found '" + lookahead.sequence + "' instead");
            }
            nextToken();
            // get Data
            mod.addAction(lookahead.sequence);
            nextToken();
        }
        nextToken();

        if (lookahead.token != Token.SEMICOLON) {
            throw new ParseError("ISPL Syntax Error : Expected ';' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();

    }

    private void Protocol() throws ParseError {
        // pr=p0 : {p_requestQuote,p_loop};
        if (!lookahead.sequence.equals("Protocol")) {
            throw new ParseError(
                    "ISPL Syntax Error : Expected 'Protocol' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        if (lookahead.token != Token.COLON) {
            throw new ParseError("ISPL Syntax Error : Expected ':' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        while (lookahead.token != Token.END) {
            protocolLine();
        }
        nextToken();
        if (!lookahead.sequence.equals("Protocol")) {
            throw new ParseError(
                    "ISPL Syntax Error : Expected 'Protocol' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();

    }

    private void protocolLine() throws ParseError {

        //Other: {b_null};
        if (lookahead.token == Token.SYNTAX) {
            // Other case :
            if (!lookahead.sequence.equals("Other")) {
                throw new ParseError(
                        "ISPL Syntax Error : Expected 'Other' but found '" + lookahead.sequence + "' instead");
            }
            nextToken();
            // verify colon
            if (lookahead.token != Token.COLON) {
                throw new ParseError("ISPL Syntax Error : Expected ':' but found '" + lookahead.sequence + "' instead");
            }
            nextToken();
            // verify {
            if (lookahead.token != Token.O_BRACKET) {
                throw new ParseError("ISPL Syntax Error : Expected '{' but found '" + lookahead.sequence + "' instead");
            }
            nextToken();
            // get first action for state
            Agent temp = GlobalAgents.get(ModCount - 1);
            temp.setDefaultAction(lookahead.sequence);

            //temp.validateOtherActions();
//			mod.removeAction(lookahead.sequence);
            nextToken();
            while (lookahead.token != Token.C_BRACKET) {
                if (lookahead.token != Token.COMMA) {
                    throw new ParseError(
                            "ISPL Syntax Error : Expected ',' but found '" + lookahead.sequence + "' instead");
                }
                nextToken();
                // get other action
                //???? Why ? There's no need, only one default action.
//				mod.removeAction(lookahead.sequence);
                nextToken();
            }
            nextToken();
            // verify semicolon
            if (lookahead.token != Token.SEMICOLON) {
                throw new ParseError("ISPL Syntax Error : Expected ';' but found '" + lookahead.sequence + "' instead");
            }
            nextToken();
        } else {
            //b_1=b0 : {b_requestQuote};
            // get name of state variable.
            Agent temp = GlobalAgents.get(ModCount - 1);
            List<String> tempActions = new ArrayList<String>();
            temp.setStateVariable(lookahead.sequence);
            nextToken();
            // verify equals
            if (lookahead.token != Token.EQUAL) {
                throw new ParseError("ISPL Syntax Error : Expected '=' but found '" + lookahead.sequence + "' instead");
            }
            nextToken();
            // get state
            String tempState = lookahead.sequence;
            nextToken();
            // verify colon
            if (lookahead.token != Token.COLON) {
                throw new ParseError("ISPL Syntax Error : Expected ':' but found '" + lookahead.sequence + "' instead");
            }
            nextToken();
            // verify {
            if (lookahead.token != Token.O_BRACKET) {
                throw new ParseError("ISPL Syntax Error : Expected '{' but found '" + lookahead.sequence + "' instead");
            }
            nextToken();
            // get first action for state
            tempActions.add(lookahead.sequence);
            nextToken();
            while (lookahead.token != Token.C_BRACKET) {
                if (lookahead.token != Token.COMMA) {
                    throw new ParseError(
                            "ISPL Syntax Error : Expected ',' but found '" + lookahead.sequence + "' instead");
                }
                nextToken();
                // get other action
                tempActions.add(lookahead.sequence);
                nextToken();
            }
            nextToken();
            // verify semicolon
            if (lookahead.token != Token.SEMICOLON) {
                throw new ParseError("ISPL Syntax Error : Expected ';' but found '" + lookahead.sequence + "' instead");
            }
            temp.AddStateAction(tempState, tempActions);
            nextToken();
        }
    }

    private void Evolution() throws ParseError {

        if (!lookahead.sequence.equals("Evolution")) {
            throw new ParseError(
                    "ISPL Syntax Error : Expected 'Evolution' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        if (lookahead.token != Token.COLON) {
            throw new ParseError("ISPL Syntax Error : Expected ':' but found '" + lookahead.sequence + "' instead");
        }
        Module mod = modules.get(ModCount - 1);
        mod.setEval("TRANS ( next (state ) = case \n");
        nextToken();
        while (lookahead.token != Token.END) {
            EvolutionLine();
        }
        nextToken();
        if (!lookahead.sequence.equals("Evolution")) {
            throw new ParseError(
                    "ISPL Syntax Error : Expected 'Evolution' but found '" + lookahead.sequence + "' instead");
        }

        mod.setEval("TRUE : state;\n esac)\n");
        nextToken();


    }

    private void EvolutionLine() throws ParseError {
        // pr=p0 if pr=p4 and Action=p_null;

        String var = "";
        String value = "";
        String source = "";
        String externalAgent = "";
        Module mod = modules.get(ModCount - 1);
        Agent temp = GlobalAgents.get(ModCount - 1);
        Transition t = new Transition();
        String current = "";
        boolean past = false;
        boolean first = false;
        boolean second = false;
        boolean localAction = false;
        boolean externalAction = false;
        boolean ignore = false;
        State s = new State();
        finalSMV = new StringBuilder();
        while (lookahead.token != Token.SEMICOLON) {
            if (externalAction) {
                t.addExternalAction(externalAgent, lookahead.sequence);
                externalAction = false;
            }
            if (localAction) {
                t.setLocalAction(lookahead.sequence);
                localAction = false;
            }
            // get data
            if (!first) {
                mod.setState(lookahead.sequence);
                mod.ValidateStates();
                //source = lookahead.sequence;
            }
            if (past) {

                if (mod.getState().equals(lookahead.sequence)) {
                    finalSMV.append("( state = ");
                    ignore = false;
                } else {
                    String now = lookahead.sequence;
                    if (now.equals("Action")) {
                        finalSMV.append("& action = ");
                        localAction = true;
                        ignore = false;
                    } else if (now.contains(".Action")) {

                        String[] h = now.split("\\.");
                        // h[0] is a call to another agent's action !

                        finalSMV.append("& " + h[0] + "-action = ");
                        mod.addOther(h[0]);
                        externalAgent = h[0];
                        externalAction = true;
                        ignore = false;
                    } else {

                        ignore = true;
                    }
                }
            }
            // pr=p0 if pr=p4 and Action=p_null;
            else {

                var = lookahead.sequence;

            }
            nextToken();
            //verify equal
            if (lookahead.token != Token.EQUAL) {
                throw new ParseError("ISPL Syntax Error : Expected '=' but " +
                        "found '" + lookahead.sequence + "' instead in " +
                        "Evolution Line");
            }
            nextToken();
            // get data
            if (!first) {
                current = lookahead.sequence;
                first = true;
            }
            if (past) {
                if (second) {
                    source = lookahead.sequence;
                    t.setSource(source);
                    second = false;
                }
                if (!ignore) {
                    finalSMV.append(lookahead.sequence + " ");
                    ignore = false;
                }

            } else {

                value = lookahead.sequence;
            }
            //finalSMV.append("( state = "+lookahead.sequence+"");
            nextToken();
            if (lookahead.token == Token.SYNTAX) {
                // get syntax data
                if (lookahead.sequence.equals("if")) {
                    past = true;
                    second = true;
                }
                nextToken();
            } else {
                if (lookahead.token != Token.SEMICOLON) {
                    throw new ParseError("ISPL Syntax Error : Expected ';' but found '" + lookahead.sequence + "' instead");
                }
            }

            if (var != "") {
                if (mod.getState().equals(var)) {
                    s = mod.getByName(value);
                } else {
                    s.addValue(var, value);
                    t.addgoalLocalVariableValues(var, value);
                }
            }
            var = value = "";
        }
        finalSMV.append(" ) : " + current + " ;\n");
        mod.setEval(finalSMV.toString());
        mod.ValidateStates();
        mod.setTrans(source, current);
        t.setDestination(current);
        temp.addStateTransition(t);
        //System.out.println("This is the evolution smv inserted :"+finalSMV.toString());
        nextToken();
        
    }
    
    private void Propositions() throws ParseError {
    //	System.out.println(lookahead.sequence);
        // verify evaluation
        if (lookahead.token != Token.EVALUATION) {
            throw new ParseError("ISPL Syntax Error : Expected 'Evaluation' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
     //   System.out.println(lookahead.sequence);
        while (lookahead.token != Token.END) {
            EvaluationLine();
        }
        nextToken();
        // verify Evaluation
        if (lookahead.token != Token.EVALUATION) {
            throw new ParseError("ISPL Syntax Error : Expected 'Evaluation' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        Expression();
        
    }

    private String getCorespAbrev(String s) {
        for (Module m : modules) {
            if (s.equals(m.getName())) {
                return m.getAbrev();
            }
        }
        return "";
    }

    private void EvaluationLine() throws ParseError {
        // read proposition
    	
        prop = prop + "DEFINE " + lookahead.sequence ;
        nextToken();
       
        // syntax : if
        nextToken();
        if (lookahead.sequence.contentEquals("tf")) {
        	prop = prop + " := FALSE;---";
        }else
        	prop = prop + " := ";	
    	
        System.out.println(lookahead.sequence);
        nextToken();
      //  System.out.println(lookahead.sequence);
        // first part
        nextToken();
        String[] f = lookahead.sequence.split("\\.");
        prop = prop + getCorespAbrev(f[0]) + ".state = ";
        nextToken();
         
        System.out.println(prop);
      //  System.out.println(lookahead.sequence);
        // equal
        if (lookahead.token != Token.EQUAL) {
            throw new ParseError("ISPL Syntax Error : Expected '=' but found " +
                    "'" + lookahead.sequence + "' instead in Evaluation Line");
        }
        nextToken();
        // second part
        prop = prop + lookahead.sequence + " ";
        nextToken();
        while (lookahead.token != lookahead.SEMICOLON) {
            // get syntax
            if (lookahead.token != Token.SYNTAX) {
                throw new ParseError("ISPL Syntax Error : Expected logical operator but found '" + lookahead.sequence + "' instead");
            }
            prop = prop + " | ";
            nextToken();
            // first part
            String[] t = lookahead.sequence.split("\\.");
            prop = prop + getCorespAbrev(t[0]) + ".state = ";
            nextToken();
            //equal
            if (lookahead.token != Token.EQUAL) {
                throw new ParseError("ISPL Syntax Error : Expected '=' but " +
                        "found '" + lookahead.sequence + "' instead in Evaluation Line");
            }
            nextToken();
            //second part
            prop = prop + lookahead.sequence + " ";
            nextToken();
        }
        prop = prop + lookahead.sequence + "\n";
        nextToken();
    }

    private Module getFromName(String name) {
        for (Module m : modules) {
            if (m.getName().equals(name)) {
                return m;
            }
        }
        return null;
    }

    private void init() throws ParseError {
        // verify init
        boolean go = false;
        if (lookahead.token != Token.INIT) {
            throw new ParseError("ISPL Syntax Error : Expected 'InitStates' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        // read first
        String[] f = lookahead.sequence.split("\\.");
        Module m = getFromName(f[0]);
        if (f.length > 1) {
            if (f[1].equals(m.state)) {
                go = true;
            }
        }
        nextToken();
        //read equal
        nextToken();
        // read second
        if (go) {
            m.setInit(lookahead.sequence);
            go = false;
        }
        nextToken();
        while (lookahead.token != Token.SEMICOLON) {
            // get Syntax
            if (lookahead.token != Token.SYNTAX) {
                throw new ParseError("ISPL Syntax Error : Expected logical operator but found '" + lookahead.sequence + "' instead");
            }
            nextToken();
            // first part
            f = lookahead.sequence.split("\\.");
            m = getFromName(f[0]);
            if (f.length > 1) {
                if (f[1].equals(m.state)) {
                    go = true;
                }
            }
            nextToken();
            //equal
            if (lookahead.token != Token.EQUAL) {
                throw new ParseError("ISPL Syntax Error : Expected '=' but found '" + lookahead.sequence + "' instead");
            }
            nextToken();
            //second part
            if (go) {
                m.setInit(lookahead.sequence);
                go = false;
            }
            nextToken();
        }
        nextToken();
        // verify end
        if (lookahead.token != Token.END) {
            throw new ParseError("ISPL Syntax Error : Expected 'end' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        // verify init
        if (lookahead.token != Token.INIT) {
            throw new ParseError("ISPL Syntax Error : Expected 'InitStates' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        Expression();
    }

    private void Formulae() throws ParseError {
        // formulae
        if (lookahead.token != Token.FORMULAE) {
            throw new ParseError("ISPL Syntax Error : Expected 'Formulae' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        while (lookahead.token != Token.END) {
            while (lookahead.token != Token.SEMICOLON) {
                formulae.append(lookahead.sequence);
                nextToken();
            }
            formulae.append(lookahead.sequence);
            formulae.append("\n");
            nextToken();
        }

        nextToken();
        if (lookahead.token != Token.FORMULAE) {
            throw new ParseError("ISPL Syntax Error : Expected 'Formulae' but found '" + lookahead.sequence + "' instead");
        }
        nextToken();
        Expression();
    }

    //char[] bc = {80, 104, 121, 115, 105,};
    // Physi
    char[] bc = {77, 97, 110, 117, 102,};
    char[] bs = {83, 101, 108, 108, 101, 114};

}
