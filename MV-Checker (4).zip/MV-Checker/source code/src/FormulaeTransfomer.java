public interface FormulaeTransfomer {

    public String parse(String input) throws ParenthesisException;

    class ParenthesisException extends Exception {
        public ParenthesisException(String errorMessage) {
            super(errorMessage);
        }
    }

}
