import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.metal.DefaultMetalTheme;
import javax.swing.plaf.metal.MetalLookAndFeel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.text.DecimalFormat;
import java.awt.Color;

public class MainFrame extends javax.swing.JFrame {
    private final TextArea txt;
    private final JPanel content;
    private final JButton generateSMVButton;
    private final JButton generatePsitiveButton;
    private final JButton generateNegativeButton; 
    private final JButton generateTFButton; 
    private final JButton generateFTButton;
    private final JButton generatePoCTLButton;
    private final JButton generateNegCTLButton;
    private final JButton generatePoCTLCButton;
    private final JButton CTLCtoCTLButton;
    private final JButton TCTLtoCTLButton;
    private final JButton loadFileButton;
    private final JButton loadFileButton1;
    private final JButton loadFileButton2;
    private final JButton loadFileButton4;
     
    private File inputFile;
    private File inputFile1;
    private File inputFile2;
    private File inputFile3;
    
    

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                MainFrame form = new MainFrame();
                form.setVisible(true);
                
            }
        });
    }
    

    @SuppressWarnings("rawtypes")
	public MainFrame() {
    	
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	Color lab1 =new Color(81, 85, 110);
    	Color lab2 =new Color(81, 85, 110);
    	JLabel label1 = new JLabel("MV-TCTL to TCTL (Classical Trust)--------------------------------------------------------------------------------------------------------------------------------------------------MV-TCTL to CTL");
    	label1.setBounds(24, 133, 2000, 30);
    	label1.setForeground(lab1);
    	this.add(label1);   	
    	JLabel label3 = new JLabel("MV-CTLC to CTLC (Classical Commitment)---------------------------------------------------------------------------------------------------------------------------------------MV-CTLC to CTL");
    	Color lab3 =new Color(81, 85, 110);
    	label3.setBounds(24, 15, 2000, 30);
    	label3.setForeground(lab3);
    	this.add(label3);
    	
     	
    	Color lab4 =new Color(81, 100, 110);
    	  	  	
          
    	setTitle("MV-CTLC-TCTL Model Checker");    		 
        setSize(1000, 1100);
        setLocation(300, 40);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);           
        Color col =new Color(189, 186, 222);
        getContentPane().setBackground(col);
        content = (JPanel) this.getContentPane();         
        txt = new TextArea();
        txt.setBounds(12, 280, 700,580);
        txt.setMaximumSize(new Dimension(600, 580));
        txt.setPreferredSize(new Dimension(600, 580));
        txt.setMaximumSize(new Dimension(800, 980));
        txt.setEditable(false);
        content.add(txt);
        
        
        // Create Button Open JFileChooser
        loadFileButton = new JButton("Upload 3V-CTLC Model");
        loadFileButton.setBounds(25, 40, 180, 30);
        col =new Color(255,255, 255);
        loadFileButton.setBackground(col);
        
      MetalLookAndFeel.setCurrentTheme(new changeTheme());                                            
        loadFileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

//                JFileChooser choose = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
                JFileChooser choose = new JFileChooser();
                choose.setDialogTitle("Load ISPL File");
                int returnVal = choose.showOpenDialog(new JFrame());
                if (returnVal == JFileChooser.APPROVE_OPTION) {

                    File expectedFile = choose.getSelectedFile();
                    inputFile = expectedFile;
                    String fileContent = loadISPLFile(expectedFile);
                    
                    if (expectedFile != null) inputFile = expectedFile;
                    txt.setText(fileContent);
                    
                }
            }
        });
        getContentPane().add(loadFileButton);
        
        loadFileButton1 = new JButton("Upload 3V-TCTL model");
        loadFileButton1.setBounds(25, 160, 180, 30);
        col =new Color(255,255, 255);
        loadFileButton1.setBackground(col);
        loadFileButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser choose = new JFileChooser();
                choose.setDialogTitle("Load ISPL File");
                int returnVal = choose.showOpenDialog(new JFrame());
                if (returnVal == JFileChooser.APPROVE_OPTION) {

                    File expectedFile = choose.getSelectedFile();
                    inputFile1 = expectedFile;
                    String fileContent1 = loadISPLFile3v(expectedFile);
                    if (expectedFile != null) inputFile1 = expectedFile;
                    txt.setText(fileContent1);
                }
            }
        });
        
        getContentPane().add(loadFileButton1);
/////////////////////////////////////////////////////////////////
        loadFileButton2 = new JButton("Upload 4V-TCTL model");
        loadFileButton2.setBounds(25, 220, 180, 30);
        col =new Color(255,255, 255);
        loadFileButton2.setBackground(col);
        loadFileButton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                 JFileChooser choose = new JFileChooser();
                choose.setDialogTitle("Load ISPL File");
                int returnVal = choose.showOpenDialog(new JFrame());
                if (returnVal == JFileChooser.APPROVE_OPTION) {

                    File expectedFile = choose.getSelectedFile();
                    inputFile2 = expectedFile;
                    String fileContent2 = loadISPLFile4v(expectedFile);
                    if (expectedFile != null) inputFile2 = expectedFile;
                    txt.setText(fileContent2);
                }
            }
        });
        
        getContentPane().add(loadFileButton2);
        
        loadFileButton4 = new JButton("Upload 4V-CTLC model");
        loadFileButton4.setBounds(25, 100, 180, 30);
        col =new Color(255,255, 255);
        loadFileButton4.setBackground(col);
        loadFileButton4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                 JFileChooser choose = new JFileChooser();
                choose.setDialogTitle("Load ISPL File");
                int returnVal = choose.showOpenDialog(new JFrame());
                if (returnVal == JFileChooser.APPROVE_OPTION) {

                    File expectedFile = choose.getSelectedFile();
                    inputFile3 = expectedFile;
                    String fileContent3 = loadISPLFile4v(expectedFile);
                    if (expectedFile != null) inputFile3 = expectedFile;
                    txt.setText(fileContent3);
                }
            }
        });
        
        getContentPane().add(loadFileButton4);
        
       
/////////////////////////////////////////////////////////////////        

        generateSMVButton = new JButton("Generate Pos-CTLC model");
        generateSMVButton.setBounds(280, 40, 180, 30);
       
        content.add(generateSMVButton);
        generateSMVButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (inputFile == null || txt.getText().length()==0){
                    throwErrorDialogue("Please load a 3v-CTLC Model before trying to generate a classical model.","Illegal Action");
                }
                
                else{
                	TrueCTLModelTraslator.transfyFile2(inputFile,  "=M "," " ,"and =M if","or ");
             	         
                }
            }     
        });
        getContentPane().add(generateSMVButton);
        
        generatePoCTLCButton= new JButton("Generate Neg-CTLC model");     
        generatePoCTLCButton.setBounds(500, 40, 180, 30);
        content.add(generatePoCTLCButton);
        generatePoCTLCButton.addActionListener(new ActionListener() {
        	@Override
            public void actionPerformed(ActionEvent e) {
                if (inputFile == null || txt.getText().length()==0){
                    throwErrorDialogue("Please load a 3v-CTLC Model before trying to generate a classical model.","Illegal Action");
                }
                
                else{
                	FCTLModelTraslator.transfyFile2(inputFile, "=M if"," if !","and =M if","or !");
             	         
                }
            }     
        });
         
        getContentPane().add(generatePoCTLCButton);
 /////////////////////////////////////////////////////////////////       
        
   CTLCtoCTLButton= new JButton("MV-CTLC to CTL");     
   CTLCtoCTLButton.setBounds(770, 40, 180, 30);
   content.add(CTLCtoCTLButton);
   CTLCtoCTLButton.addActionListener(new ActionListener() {
        	@Override
    
        		
        		public void actionPerformed(ActionEvent e) {
                    MainFrame1 frame = new MainFrame1();
                  
                     frame.setVisible(true);
        	} });      
   getContentPane().add(CTLCtoCTLButton); 
   setVisible(true);    
////////////////////////////////////////////////////////////////////        

generatePoCTLButton= new JButton("Generate FT-CTLC model");     
generatePoCTLButton.setBounds(500, 100, 180, 30);
content.add(generatePoCTLButton);
generatePoCTLButton.addActionListener(new ActionListener() {
	@Override
    public void actionPerformed(ActionEvent e) {
        if (inputFile3 == null || txt.getText().length()==0){
            throwErrorDialogue("Please load a 4v-CTLC Model before trying to generate a classical model.","Illegal Action");
        }
        
        else{
        	FTModelTraslator.transfyFile2(inputFile3, "=tf if", "if !", "=tt"," ","=ft");
     	         
        }
    }     
});
 
getContentPane().add(generatePoCTLButton);
///////////////////////////////////////////////////////////////////////////////
       	
generateNegCTLButton= new JButton("Generate TF-CTLC model");     
generateNegCTLButton.setBounds(280, 100, 180, 30);
content.add(generateNegCTLButton);
generateNegCTLButton.addActionListener(new ActionListener() {
     @Override
     public void actionPerformed(ActionEvent e) {
         if (inputFile3 == null || txt.getText().length()==0){
             throwErrorDialogue("Please load a 4v-CTLC Model before trying to generate a classical model.","Illegal Action");
         }
         else{
        	 TFModelTraslator.transfyFile2(inputFile3, "=ft if", "if !", "=tt"," ","=tf");
      	         
         }
     }     
});
  
getContentPane().add(generateNegCTLButton);

        
        generatePsitiveButton= new JButton("Generate Pos.TCTL model");     
        generatePsitiveButton.setBounds( 280, 160, 180, 30);
      content.add(generatePsitiveButton);
      generatePsitiveButton.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               if (inputFile1 == null || txt.getText().length()==0){
                   throwErrorDialogue("Please load a 3v-TCTL Model before trying to generate a classical model.","Illegal Action");
               }
               else{
            	   TrueModelTraslator.transfyFile2(inputFile1, "=M "," " ,"and =M if","or ");
            	         
               }
           }     
      });
        
 getContentPane().add(generatePsitiveButton);
 
 generateNegativeButton= new JButton("Generate Neg.TCTL model");     
 generateNegativeButton.setBounds(500, 160, 180, 30);
 content.add(generateNegativeButton);
 generateNegativeButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
          if (inputFile1 == null || txt.getText().length()==0){
              throwErrorDialogue("Please load a 3v-TCTL Model before trying to generate a classical model.","Illegal Action");
          }
          else{
        	  FCTLModelTraslator.transfyFile2(inputFile1,"=M if"," if !","and =M if","or !");
       	         
          }
      }     
 });
   
getContentPane().add(generateNegativeButton);

TCTLtoCTLButton= new JButton("MV-TCTL to CTL");     
TCTLtoCTLButton.setBounds(770, 160, 180, 30);
content.add(TCTLtoCTLButton);
TCTLtoCTLButton.addActionListener(new ActionListener() {
     	@Override
     	public void actionPerformed(ActionEvent e) {
            MainFrame2 frame = new MainFrame2();
          
             frame.setVisible(true);
	} });      
getContentPane().add(CTLCtoCTLButton); 
setVisible(true);

///////////////////////////////////////////////////////
generateTFButton= new JButton("Generate TF-TCTL model");     
generateTFButton.setBounds(280, 220, 180, 30);
content.add(generateTFButton);
generateTFButton.addActionListener(new ActionListener() {
     @Override
     public void actionPerformed(ActionEvent e) {
         if (inputFile2 == null || txt.getText().length()==0){
             throwErrorDialogue("Please load a 4v-TCTL Model before trying to generate a classical model.","Illegal Action");
         }
         else{
        	 TFModelTraslator.transfyFile2(inputFile2, "=ft if", "if !", "=tt"," ","=tf");
      	         
         }
     }     
});
  
getContentPane().add(generateTFButton);

generateFTButton= new JButton("Generate FT-TCTL model");     
generateFTButton.setBounds(500, 220, 180, 30);
content.add(generateTFButton);
generateFTButton.addActionListener(new ActionListener() {
     @Override
     public void actionPerformed(ActionEvent e) {
         if (inputFile2 == null || txt.getText().length()==0){
             throwErrorDialogue("Please load a 4v-TCTL Model before trying to generate a classical model.","Illegal Action");
         }
         else{
       	  FTModelTraslator.transfyFile2(inputFile2, "=tf if", "if !", "=tt"," ","=ft");
      	         
         }
     }     
});
  
getContentPane().add(generateFTButton);

 
    }	
    private String loadISPLFile(File f) {
        StringBuilder b = new StringBuilder("");
        try {
            BufferedReader reader = new BufferedReader(new FileReader(f));
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (line.contains("--")) {
                    b.append(line.split("--")[0]);
                } else {
                    b.append(line + "\n");  
            }
            }
        } catch (FileNotFoundException e) {

            throwErrorDialogue("Unable to read from the ISPL Input File !", "File Not Found");

        } catch (IOException e) {

            throwErrorDialogue("Unable to read from the ISPL Input File !", "File System Access Permission");
        }
        return b.toString();
    }
    
    private String loadISPLFile3v(File s) {
        StringBuilder b = new StringBuilder("");
        try {
            BufferedReader reader = new BufferedReader(new FileReader(s));
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (line.contains("--")) {
                    b.append(line.split("--")[0]);
                } else {
                    b.append(line + "\n");
                }
             
               
            }
        } catch (FileNotFoundException e) {

            throwErrorDialogue("Unable to read from the ISPL Input File !", "File Not Found");

        } catch (IOException e) {

            throwErrorDialogue("Unable to read from the ISPL Input File !", "File System Access Permission");
        }
        return b.toString();
    }
    private String loadISPLFile4v(File w) {
        StringBuilder b = new StringBuilder("");
        try {
            BufferedReader reader = new BufferedReader(new FileReader(w));
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (line.contains("--")) {
                    b.append(line.split("--")[0]);
                } else {
                    b.append(line + "\n");
                }
              
                
               
            }
        } catch (FileNotFoundException e) {

            throwErrorDialogue("Unable to read from the ISPL Input File !", "File Not Found");

        } catch (IOException e) {

            throwErrorDialogue("Unable to read from the ISPL Input File !", "File System Access Permission");
        }
        return b.toString();
    }
    
    private static void throwErrorDialogue(String errorMessage, String typeOfError) {
        JOptionPane.showMessageDialog(new JFrame(), errorMessage, typeOfError, JOptionPane.ERROR_MESSAGE);
    }


    @SuppressWarnings("serial")
    static class mcmas extends JFrame implements ActionListener {
    	 
    	
    	
        static String modelOutput = "";
        static String modelFileSaved = "C:\\JTL\\scal.out";

        long formulae, starts, ends;
        double mo, fo;
        static double[] formulaTable;

        @SuppressWarnings("static-access")
        public mcmas(String h, double m, double f, double[] formulaTimeTable) {
            this.setName("mcmas Launch Interface");
            initComponents();
            jTextArea1.setText(h);
            mo = m;
            fo = f;
            if (formulaTimeTable != null) {
                this.formulaTable = formulaTimeTable;
                formulae = 0;
                for (int i = 0; i < formulaTimeTable.length; ++i) {
                    formulae += formulaTimeTable[i];
                }
            }

        }


        private void initComponents() {

            jPanel1 = new JPanel();           
            jScrollPane1 = new JScrollPane();
            jTextArea1 = new JTextArea();
            launchmcmasButton = new JButton();
            jPanel2 = new JPanel();
            jScrollPane2 = new JScrollPane();
            jTextArea2 = new JTextArea();
            jLabel1 = new JLabel();
            jTextField1 = new JTextField();
            jLabel2 = new JLabel();
            jTextField2 = new JTextField();
            jLabel3 = new JLabel();
            jTextField3 = new JTextField();
            jTextField4 = new JTextField();
            jLabel4 = new JLabel();
            timeFormulaButton = new JButton();

            setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

            jScrollPane1.setBorder(BorderFactory.createTitledBorder("CTL Model"));              
            jTextArea1.setColumns(20);
            jTextArea1.setRows(5);
            jTextArea1.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
            jScrollPane1.setViewportView(jTextArea1);
            jTextArea1.getAccessibleContext().setAccessibleName("");

            launchmcmasButton.setText("Launch mcmas");

            jPanel2.setBorder(BorderFactory.createTitledBorder("Verification Results"));

            jTextArea2.setColumns(20);
            jTextArea2.setRows(5);
            jScrollPane2.setViewportView(jTextArea2);

            GroupLayout jPanel2Layout = new GroupLayout(jPanel2);
            jPanel2.setLayout(jPanel2Layout);
            jPanel2Layout.setHorizontalGroup(
                    jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jScrollPane2)
                                    .addContainerGap())
            );
            jPanel2Layout.setVerticalGroup(
                    jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jScrollPane2, GroupLayout.DEFAULT_SIZE, 299, Short.MAX_VALUE)
                                    .addContainerGap())
            );

            jLabel1.setText("Time of Transofrming Model");

            jTextField1.setText("0ms");

            jLabel2.setText("Total Time of Transforming Formulas");

            jTextField2.setText("0ms");

            jLabel3.setText("Time of Verification Process");

            jTextField3.setText("0ms");

            jTextField4.setText("0ms");

            jLabel4.setText("Total Time");

            timeFormulaButton.setForeground(new Color(0, 102, 255));
            timeFormulaButton.setText("Time/Formula");
            timeFormulaButton.setBorder(null);

            GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
                   
            jPanel1.setLayout(jPanel1Layout);
            jPanel1Layout.setHorizontalGroup(
                    jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 490, GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(launchmcmasButton)
                                                    .addGap(0, 0, Short.MAX_VALUE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jPanel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addContainerGap())
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                                                            .addGroup(GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                                    .addComponent(jLabel4)
                                                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                    .addComponent(jTextField4, GroupLayout.PREFERRED_SIZE, 186, GroupLayout.PREFERRED_SIZE))
                                                            .addGroup(GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                                            .addComponent(jLabel1)
                                                                            .addComponent(jLabel3)
                                                                            .addComponent(jLabel2))
                                                                    .addGap(25, 25, 25)
                                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                                            .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
                                                                            .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
                                                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                    .addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
                                                                                    .addGap(18, 18, 18)
                                                                                    .addComponent(timeFormulaButton)))))
                                                    .addGap(49, 49, Short.MAX_VALUE))))
            );
            jPanel1Layout.setVerticalGroup(
                    jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(launchmcmasButton)
                                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jPanel2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                    .addGap(18, 18, 18)
                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                            .addComponent(jLabel1)
                                                            .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                    .addGap(9, 9, 9)
                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                            .addComponent(jLabel2)
                                                            .addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(timeFormulaButton))
                                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                            .addComponent(jLabel3)
                                                            .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                    .addGap(18, 18, Short.MAX_VALUE)
                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                            .addComponent(jTextField4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(jLabel4)))
                                            .addComponent(jScrollPane1))
                                    .addContainerGap())
            );

            GroupLayout layout = new GroupLayout(getContentPane());
            getContentPane().setLayout(layout);
            layout.setHorizontalGroup(
                    layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addContainerGap())
            );
            layout.setVerticalGroup(
                    layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addContainerGap())
            );

            jPanel1.getAccessibleContext().setAccessibleName("CTL Model");
            launchmcmasButton.addActionListener(this);
            timeFormulaButton.addActionListener(this);
            pack();
        }// </editor-fold>

        private void runScalableModel() {
            // save file to run with mcmas
            saveGeneratedFile();
            starts = System.nanoTime();
            try {
                modelOutput = mcmasInteractor.runmcmasModel();
            } catch (IOException e) {
                JOptionPane
                        .showMessageDialog(
                                new JFrame(),
                                "The tool couldn't access files on the system, Please verify its running with admin privileges",
                                "File System Access Denied", JOptionPane.ERROR_MESSAGE);
            } finally {
                ends = System.nanoTime();
            }
            DecimalFormat formatter = new DecimalFormat("#00.000000");
            double process = (ends - starts) / (double) (cst);
            jTextField1.setText("" + formatter.format(mo) + "ms");
            jTextField2.setText("" + formatter.format(fo) + "ms");
            jTextField3.setText("" + formatter.format(process) + "ms");
            jTextField4.setText("" + formatter.format(mo + fo + process) + "ms");
            jTextArea2.setText(modelOutput);
        }

        private JButton launchmcmasButton;
        private JButton timeFormulaButton;
        private JLabel jLabel1;
        private JLabel jLabel2;
        private JLabel jLabel3;
        private JLabel jLabel4;
        private JPanel jPanel1;
        private JPanel jPanel2;
        private JScrollPane jScrollPane1;
        private JScrollPane jScrollPane2;
        private JTextArea jTextArea1;
        private JTextArea jTextArea2;
        private JTextField jTextField1;
        private JTextField jTextField2;
        private JTextField jTextField3;
        private JTextField jTextField4;
        static double cst = 10000000;
        public void saveGeneratedFile() {
            File file = new File(modelFileSaved);
            Writer output = null;
            try {
                output = new BufferedWriter(new FileWriter(file));
                output.write(jTextArea1.getText());
                output.close();
            } catch (IOException e) {
                //e.printStackTrace();
                JOptionPane
                        .showMessageDialog(
                                new JFrame(),
                                "The tool couldn't access files on the system, Please verify its running with admin priveleges",
                                "File System Access Denied", JOptionPane.ERROR_MESSAGE);
            }
        }


        @Override
        public void actionPerformed(ActionEvent arg0) {

            if (arg0.getSource() == launchmcmasButton) {
                runScalableModel();
            } else if (arg0.getSource() == timeFormulaButton) {
                JComponent[] input = new JComponent[2 * formulaTable.length];
                for (int i = 0; i < formulaTable.length; ++i) {
                    JLabel lab = new JLabel("Formula " + (i + 1));
                    JLabel labs = new JLabel(formulaTable[i] + "ms");
                    input[2 * i] = lab;
                    input[2 * i + 1] = labs;
                }
                @SuppressWarnings("unused")
                int result = JOptionPane.showConfirmDialog(null, input, "Time/Formula", JOptionPane.PLAIN_MESSAGE);
            }

        }
    }
     
}

class changeTheme extends DefaultMetalTheme {
Color	col =new Color(0,87, 157);
    public ColorUIResource getWindowTitleInactiveBackground() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getWindowTitleBackground() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getPrimaryControlHighlight() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getPrimaryControlDarkShadow() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getPrimaryControl() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getControlHighlight() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getControlDarkShadow() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getControl() {
      return new ColorUIResource(col);
    }
}
