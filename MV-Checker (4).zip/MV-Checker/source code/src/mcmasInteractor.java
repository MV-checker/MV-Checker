import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;

public class mcmasInteractor {


    static final String mcmasCommands = "mcmas";
    static final String mcmasParameters = "-v 1 ";
   // static final String pars = "-u";
    static final String modelFileSaved = "C:\\JTL\\scal.out";
   


    public mcmasInteractor() {
    }

    public static String runmcmasModel() throws IOException {

        String modelOutput = "";
        final Vector<String> command = new Vector<String>();
        command.add(mcmasCommands);
        final StringTokenizer tokens = new StringTokenizer(
                mcmasParameters, " ");
        while (tokens.hasMoreTokens()) {
            command.add(tokens.nextToken());
        }

     //   command.add(pars);
        command.add(modelFileSaved);
       final ProcessBuilder builder = new ProcessBuilder(command);
        builder.redirectErrorStream(true);
       final Process process = builder.start();
       final InputStream lsOut = process.getInputStream();
       final InputStreamReader r = new InputStreamReader(lsOut);
       final BufferedReader in = new BufferedReader(r);
        String line;
       while ((line = in.readLine()) != null) {
            modelOutput = String.valueOf(modelOutput) + line + "\n";
        }

        modelOutput = decodeIntoTextFormat(modelOutput);

       return modelOutput;

    }
    // this method transforms the bites returned by nusmv into string
    private static String decodeIntoTextFormat(String modelOutput) {
        return mcmasWorker.decodeBits(modelOutput);
    }


}
