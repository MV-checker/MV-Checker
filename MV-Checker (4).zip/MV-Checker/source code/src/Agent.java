import java.util.*;


public class Agent {
	public boolean back;
	/**
	 * Default action of this agent
	 */
	private String defaultAction;//
	/**
	 * Name of agent
	 */
	private String name;//
	/**
	 * Abbreviation
	 */
	private String abbrev;//
	/**
	 * All possible states of agent
	 */
	private List<String> states;//
	/**
	 * Initial state index in array
	 */
	private int InitialState;
	/**
	 * current State in the agent simulation.
	 */
	private String currentState;
	/**
	 * current value of all variables
	 */
	private Map<String,String> currentVarValues;
	/**
	 * All possible values for every variable
	 * Order is according to the same order as variables names
	 */
	private List<List<String> > allvariableEnumerations;//
	/**
	 * All variable names
	 */
	private List<String> vars;//

	/**
	 * Association of each state to its possible actions
	 * Other handeled
	 */
	private Map<String,List<String> > stateActions;//
	/**
	 * Association of each action and its transition element
	 */
	private List<Transition> stateTransitions;//
	/**
	 * List of all external agents names;
	 * we can then get them by names or abbreviation or whatever!
	 */
	private Set<String> externalAgents;//
	
	private String stateVariable;//
	
	
	
	
	
	
	public List<String> getActionFromState(String state)
	{
		return stateActions.get(state);
	}
	public Agent() 
	{
		stateActions = new HashMap<String,List<String> >();
		stateTransitions = new ArrayList<Transition>();
		
	}
	
	public void addStateTransition (Transition t)
	{
		stateTransitions.add(t);
	}
	
	public String getStateVariable() {
		return stateVariable;
	}
	public void setStateVariable(String stateVariable) {
		this.stateVariable = stateVariable;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getStates() {
		return states;
	}
	public void setStates(List<String> states) {
		this.states = states;
	}
	public int getInitialState() {
		return InitialState;
	}
	public void setInitialState(int initialState) {
		InitialState = initialState;
	}
	public String getCurrentState() {
		return currentState;
	}
	public void setCurrentState(String currentState) {
		this.currentState = currentState;
	}
	public Map<String, String> getCurrentVarValues() {
		return currentVarValues;
	}
	public void setCurrentVarValues(Map<String, String> currentVarValues) {
		this.currentVarValues = currentVarValues;
	}
	public List<List<String>> getAllvariableEnumerations() {
		return allvariableEnumerations;
	}
	public void setAllvariableEnumerations(List<List<String>> allvariableEnumerations) {
		this.allvariableEnumerations = allvariableEnumerations;
	}
	public List<String> getVars() {
		return vars;
	}
	public void setVars(List<String> vars) {
		this.vars = vars;
	}
	public Map<String, List<String>> getStateActions() {
		return stateActions;
	}
	public void setStateActions(Map<String, List<String>> stateActions) {
		this.stateActions = stateActions;
	}
	
	public List<Transition> getStateTransitions() {
		return stateTransitions;
	}
	public void setStateTransitions(List<Transition> stateTransitions) {
		this.stateTransitions = stateTransitions;
	}
	
	public Set<String> getExternalAgents() {
		return externalAgents;
	}

	public void setExternalAgents(Set<String> externalAgents) {
		this.externalAgents = externalAgents;
	}

	public String getAbbrev() {
		return abbrev;
	}
	public void setAbbrev(String abbrev) {
		this.abbrev = abbrev;
	}
	
	public void getData (Module m)
	{
		// getting all states
		String states = m.vars.get(m.states);
		String [] h = states.split(" ");
		int cnt = 0;
		this.states = new ArrayList<String>();
		for (String s : h)
		{
			if (cnt>0)
			{
				this.states.add(s);
			}
		}
		validateOtherActions();
		
		// getting all variable names
		// getting enumerations of each variable
		cnt = 0;
		this.vars = new ArrayList<String>();
		allvariableEnumerations = new ArrayList<List<String>>();
		for (String s : m.vars )
		{
			if (cnt != m.states)
			{
				List<String> mm = new ArrayList<String>();
				String [] r = s.trim().split(" ");
				int fa = 0;
				for (String ss : r)
				{
					if (fa == 0)
					{
						vars.add(ss);
					}
					else
					{
						mm.add(ss);
					}
				}
				allvariableEnumerations.add(mm);				
			}
		}
		// getting other agents
		this.externalAgents = m.other;
		
		
	}
	
	
	
	public String getDefaultAction() {
		return defaultAction;
	}
	public void setDefaultAction(String defaultAction) {
		this.defaultAction = defaultAction;
	}
	
	public void AddStateAction (String state, List<String>actions)
	{
		if (actions == null )
		{
			actions = new ArrayList<String>();
			actions.add(defaultAction);
			stateActions.put(state, actions);
		}
		else if (actions.isEmpty())
		{
			actions.add(defaultAction);
			stateActions.put(state, actions);
		}
		else
		{
			stateActions.put(state, actions);
		}
		
	}
	
	public void validateOtherActions ()
	{
		for (String s : states)
		{
			if (!stateActions.containsKey(s))
			{
				List<String> actions = new ArrayList<String>();
				actions.add(defaultAction);
				stateActions.put(s, actions);
			}
		}
	}
	
	
	public void init()
	{
		InitialState = 0;
		currentState = states.get(InitialState);
		currentVarValues = new HashMap<String,String>();
		int indx = 0;
		for (String v : vars)
		{
			String initV = allvariableEnumerations.get(indx).get(0);
			currentVarValues.put(v, initV);
		}
		back = true;
	}
	@Override
	public String toString() {
		return "Agent [back=" + back + ", defaultAction=" + defaultAction + ", name=" + name + ", abbrev=" + abbrev
				+ ", states=" + states + ", InitialState=" + InitialState + ", currentState=" + currentState
				+ ", currentVarValues=" + currentVarValues + ", allvariableEnumerations=" + allvariableEnumerations
				+ ", vars=" + vars + ", stateActions=" + stateActions + ", stateTransitions=" + stateTransitions
				+ ", externalAgents=" + externalAgents + ", stateVariable=" + stateVariable + "]";
	}
	
	
	
	
	
	
	
	
	
}
