import java.util.*;
import java.util.stream.Collectors;

public class BranchingCommToSMV implements FormulaeTransfomer {

    Map<Integer, Integer> map;

    class Pair {
        Character c;
        Integer indx;

        public Pair(Character c, Integer indx) {
            this.c = c;
            this.indx = indx;
        }
    }

    @Override
    public String parse(String input) throws ParenthesisException {
        map = createParenthesisParsingMap(input);
        return action(input);
    }

    private String preprocessGroup(String s) {
        String pattern = "\\{(.+)}";
//        System.out.println(input.replaceAll(pattern, "[$1]"));
        List<String> agents = Arrays.stream(s.replaceAll(pattern, "$1").split(",")).collect(Collectors.toList());
        // all agents
        List<String> sorted = agents.stream().sorted().collect(Collectors.toList());
        return appendAgents(sorted);
    }

    private String appendAgents(List<String> agents) {
        StringBuilder st = new StringBuilder();
        for (int i = 0; i < agents.size(); i++) {
            String a = agents.get(i);
            if (i != 0) {
                st.append("-");
            }
            st.append(a);
        }
        return st.toString();
    }

    public Map<Integer, Integer> createParenthesisParsingMap(String s) throws ParenthesisException {
        // will push pair : Character and index
        //
        Map<Integer, Integer> map = new HashMap<>();
        ArrayDeque<Pair> stack = new ArrayDeque<>();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(') {
                stack.push(new Pair(c, i));
            } else if (c == ')') {
                if (stack.isEmpty()) {
                    throw new ParenthesisException("Formula is not well structured");
                }
                Pair top = stack.pop();
                map.put(top.indx, i);
            }
        }
        if (!stack.isEmpty()) throw new ParenthesisException("Formula is not well structured");
        return map;
    }

    public int getClosingIndexOf(String s, int k) throws ParenthesisException {
        Map<Integer, Integer> map = new HashMap<>();
        ArrayDeque<Pair> stack = new ArrayDeque<>();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '[') {
                stack.push(new Pair(c, i));
            } else if (c == ']') {
                if (stack.isEmpty()) {
                    throw new ParenthesisException("Formula is not well structured");
                }
                Pair top = stack.pop();
                map.put(top.indx, i);
                if (top.indx == k) {
                    return i;
                }
            }
        }
        throw new ParenthesisException("Formula is not well structured");
    }

    public String E(String p, String q) {
        return "E[(" + p + " & !chi) U (" + q + " & !chi )]";
    }

    public String EUntil(String in) throws ParenthesisException {
        for (int i = 0; i < in.length() - 3; i++) {
            String sub = in.substring(i);
            StringBuilder st = new StringBuilder();
            if (sub.startsWith("E[")) {
                final int indexOfStart = i + 1;
                Integer last = getClosingIndexOf(in, indexOfStart);
                int operator = in.indexOf("U", indexOfStart);
                String p = in.substring(indexOfStart + 1, operator);
                String q = in.substring(operator + 1, last);
                String prefix = in.substring(0, i);
                String suffix = "";
                if (last + 1 < in.length())
                    suffix = in.substring(last + 1);
                st.append(prefix);
                st.append(E(p, q));
                st.append(suffix);
                in = st.toString();
            }
        }


        return in;
    }

    public String EX(String frag) {
        return "EX (" + frag + " & !chi )";
    }
    public String parseEX(String in) throws ParenthesisException {
        String s = in;
        String res = "";
        for (int i = 0; i < in.length() - 3; i++) {
            map = createParenthesisParsingMap(in);
            String sub = in.substring(i);
            StringBuilder st = new StringBuilder();
            if (sub.startsWith("EX(")) {
                final int indexOfStart = i + 2;
                Integer last = map.get(indexOfStart);
                String fragment = in.substring(indexOfStart + 1, last);
                String prefix = in.substring(0, i);
                String suffix = "";
                if (last + 1 < in.length())
                    suffix = in.substring(last + 1);
                st.append(prefix);
                st.append(EX(fragment));
                st.append(suffix);
                in = st.toString();
            }
        }
        return in;
    }

    public String EG(String frag) {
        return "EG (" + frag + " & !chi )";
    }

    public String parseEG(String in) throws ParenthesisException {
        String s = in;
        String res = "";
        for (int i = 0; i < in.length() - 3; i++) {
            map = createParenthesisParsingMap(in);
            String sub = in.substring(i);
            StringBuilder st = new StringBuilder();
            if (sub.startsWith("EG(")) {
                final int indexOfStart = i + 2;
                Integer last = map.get(indexOfStart);
                String fragment = in.substring(indexOfStart + 1, last);
                String prefix = in.substring(0, i);
                String suffix = "";
                if (last + 1 < in.length())
                    suffix = in.substring(last + 1);
                st.append(prefix);
                st.append(EG(fragment));
                st.append(suffix);
                in = st.toString();
            }
        }
        return in;
    }

    public boolean correctParenthese(String res) {
        int cnt = 0;
        for (int i = 0; i < res.length(); i++) {
            if (res.charAt(i) == '(') cnt++;
            if (res.charAt(i) == ')') cnt--;
        }
        return (cnt == 0);
    }

    public int getParenthesisIndex(String in, int opening) {
        int cnt = 0;
        for (int i = opening + 1; i < in.length(); i++) {
            if (in.charAt(i) == ')') {
                if (cnt != 0) {
                    cnt--;
                } else {
                    return i;
                }
            } else if (in.charAt(i) == '(') {
                cnt++;
            }
        }
        return in.length() - 1;
    }

    public String action(String s) throws ParenthesisException {
        if (s != "") {
            s = removeWhiteSpace(s);
            if (s.length() == 0)
                return s;
            s = parseEX(s);
            s = parseEG(s);
            s = parseEt(s);
            s = parsePt(s);
            s = parseDt(s);
            s = parseT(s);
            s = EUntil(s);
            s = "SPEC " + s;
            s = s.replace("and", " & ");
            s = s.replace("OR", " | ");
            s = s.replace("AND", " & ");
            s = s.replace("EF", "EF ");
            s = s.replace("AF", "AF ");
            s = s.trim();
            if (s.charAt(s.length()-1) != ';'){
                s = s + ";";
            }
        }
        // we did something wrong in the transformation
        if (!correctParenthese(s)) throw new ParenthesisException("Formula is not well structured");
        return s;
    }

    public void init(String h) throws ParenthesisException {
        map = createParenthesisParsingMap(h);
    }


    public String parseT(String s) {
        String h = s;
        int current = 0;
        String result = "";

        final int T_SIZE = 2;
        final int BLOCK_SIZE = 1 + T_SIZE;
        final int I_SIZE = 1 + T_SIZE;
        final int J_SIZE = 1 + I_SIZE;
//        final int PSI_SIZE = 1 + J_SIZE;
        final int PHI_SIZE = 1 + J_SIZE;

        while (true) {
            int indx = s.lastIndexOf("C(");

            if (indx < 0)
                break;
            String i = s.substring(indx + T_SIZE, s.indexOf(",", indx));
            String j = s.substring(indx + I_SIZE + i.length(),
                    s.indexOf(",", indx + I_SIZE + i.length()));
            int opening = indx + J_SIZE + i.length() + j.length();
            String phi = s.substring(opening, getParenthesisIndex(s, opening));
            result = s.substring(0, indx)
                    + C(i, j, phi)
                    + s.substring(indx + PHI_SIZE + i.length() + j.length()
                    + phi.length());
            current = indx + 1;
            if (result != "")
                s = result;
        }
        if (result == "") return s;
        return result;
    }

    public String C(String i, String j, String phi) {
        return String.format("AX( alpha-%s-%s -> AX(%s) )", i, j, phi);
    }

    public String parsePt(String s) {
        String h = s;
        int current = 0;
        String result = "";

        final int T_SIZE = 3;
        final int I_SIZE = 1 + T_SIZE;
        final int J_SIZE = 1 + I_SIZE;

        while (true) {
            int indx = s.lastIndexOf("PT(");

            if (indx < 0)
                break;

            int supposed = indx + T_SIZE;
            char c = s.charAt(supposed);
            while (c == ' ') {
                supposed++;
                c = s.charAt(supposed);
            }
            int fistEffectiveCharacter = supposed;

            if (s.charAt(fistEffectiveCharacter) == '{') {
                // Group of agents : parse accordingly
                int closing = findClosingBracket(s, fistEffectiveCharacter);
                String i = s.substring(fistEffectiveCharacter, closing + 1);
                String j = s.substring(fistEffectiveCharacter + 1 + i.length(),
                        s.indexOf(",", fistEffectiveCharacter + 1 + i.length()));
                int opening = fistEffectiveCharacter + 2 + i.length() + j.length();
                String phi = s.substring(opening, getParenthesisIndex(s, opening));
                result = s.substring(0, indx)
                        + Pt(i, j, phi)
                        + s.substring(fistEffectiveCharacter + 3 + i.length() + j.length()
                        + phi.length());
                current = indx + 1;
                if (result != "")
                    s = result;
            } else {
                // single agent : parse as usual
                String i = s.substring(fistEffectiveCharacter, s.indexOf(",", indx));
                String j = s.substring(fistEffectiveCharacter + 1 + i.length(),
                        s.indexOf(",", fistEffectiveCharacter + 1 + i.length()));
                int opening = fistEffectiveCharacter + 2 + i.length() + j.length();
                String phi = s.substring(opening, getParenthesisIndex(s, opening));
                result = s.substring(0, indx)
                        + Pt(i, j, phi)
                        + s.substring(fistEffectiveCharacter + 3 + i.length() + j.length()
                        + phi.length());
                current = indx + 1;
                if (result != "")
                    s = result;
            }

        }
        if (result == "") return s;
        return result;
    }

    public String Pt(String i, String j, String phi) {
        String group = preprocessGroup(i);
     //   return String.format("AX( alpha-%s-P-%s -> AX(%s) )", group, j, phi);
        return String.format("EX( alpha-%s-P-%s -> EX(%s) )", group, j, phi);
    }

    private int findClosingBracket(String s, int start) {
        for (int i = start + 1; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '}') return i;
        }
        return -1;
    }

    public String parseEt(String s) {
        String h = s;
        int current = 0;
        String result = "";

        final int T_SIZE = 3;
        final int I_SIZE = 1 + T_SIZE;

        while (true) {
            int indx = s.lastIndexOf("ET(");

            if (indx < 0)
                break;

            int supposed = indx + T_SIZE;
            char c = s.charAt(supposed);
            while (c == ' ') {
                supposed++;
                c = s.charAt(supposed);
            }
            int fistEffectiveCharacter = supposed;

            if (s.charAt(fistEffectiveCharacter) == '{') {
                // Group of agents : parse accordingly
                int closing = findClosingBracket(s, fistEffectiveCharacter);
                String i = s.substring(fistEffectiveCharacter, closing + 1);
                String j = s.substring(fistEffectiveCharacter + 1 + i.length(),
                        s.indexOf(",", fistEffectiveCharacter + 1 + i.length()));
                int opening = fistEffectiveCharacter + 2 + i.length() + j.length();
                String phi = s.substring(opening, getParenthesisIndex(s, opening));
                result = s.substring(0, indx)
                        + Et(i, j, phi)
                        + s.substring(fistEffectiveCharacter + 3 + i.length() + j.length()
                        + phi.length());
                current = indx + 1;
                if (result != "")
                    s = result;
            } else {
                // single agent : parse as usual
                String i = s.substring(fistEffectiveCharacter, s.indexOf(",", indx));
//            System.out.println("i : " + i);
                String j = s.substring(fistEffectiveCharacter + 1 + i.length(),
                        s.indexOf(",", fistEffectiveCharacter + 1 + i.length()));
//            System.out.println("j : " + j);
//            String psi = s.substring(indx + J_SIZE + i.length() + j.length(),
//                    s.indexOf(",", indx + J_SIZE + i.length() + j.length()));
//            System.out.println("phi : " + psi);

//            int opening = indx + PSI_SIZE + i.length() + j.length() + psi.length();
                int opening = fistEffectiveCharacter + 2 + i.length() + j.length();
                String phi = s.substring(opening, getParenthesisIndex(s, opening));
//            System.out.println("psi : " + phi);
                result = s.substring(0, indx)
                        + Et(i, j, phi)
                        + s.substring(fistEffectiveCharacter + 3 + i.length() + j.length()
                        + phi.length());
                current = indx + 1;
                if (result != "")
                    s = result;
            }

        }
        if (result == "") return s;
        /*if (correctParenthese(result)){
            JOptionPane.showConfirmDialog(null,"Correct Formulae Detected, Parsing ...","Status",JOptionPane.INFORMATION_MESSAGE);
        }*/
        return result;
    }

    public String Et(String i, String j, String phi) {
        String group = preprocessGroup(i);
        return String.format("AX( alpha-%s-E-%s -> AX(%s) )", group, j, phi);
//        return "AX( alpha-i)";
    }

    public String parseDt(String s) {
        String h = s;
        int current = 0;
        String result = "";

        final int T_SIZE = 3;
        final int BLOCK_SIZE = 1 + T_SIZE;
        final int I_SIZE = 1 + T_SIZE;
        final int J_SIZE = 1 + I_SIZE;
//        final int PSI_SIZE = 1 + J_SIZE;
        final int PHI_SIZE = 1 + J_SIZE;

        while (true) {
            int indx = s.lastIndexOf("DT(");

            if (indx < 0)
                break;

            int supposed = indx + T_SIZE;
            char c = s.charAt(supposed);
            while (c == ' ') {
                supposed++;
                c = s.charAt(supposed);
            }
            int fistEffectiveCharacter = supposed;

            if (s.charAt(fistEffectiveCharacter) == '{') {
                // Group of agents : parse accordingly
                int closing = findClosingBracket(s, fistEffectiveCharacter);
                String i = s.substring(fistEffectiveCharacter, closing + 1);
                String j = s.substring(fistEffectiveCharacter + 1 + i.length(),
                        s.indexOf(",", fistEffectiveCharacter + 1 + i.length()));
                int opening = fistEffectiveCharacter + 2 + i.length() + j.length();
                String phi = s.substring(opening, getParenthesisIndex(s, opening));
                result = s.substring(0, indx)
                        + Dt(i, j, phi)
                        + s.substring(fistEffectiveCharacter + 3 + i.length() + j.length()
                        + phi.length());
                current = indx + 1;
                if (result != "")
                    s = result;
            } else {
                // single agent : parse as usual
                String i = s.substring(fistEffectiveCharacter, s.indexOf(",", indx));
//            System.out.println("i : " + i);
                String j = s.substring(fistEffectiveCharacter + 1 + i.length(),
                        s.indexOf(",", fistEffectiveCharacter + 1 + i.length()));
//            System.out.println("j : " + j);
//            String psi = s.substring(indx + J_SIZE + i.length() + j.length(),
//                    s.indexOf(",", indx + J_SIZE + i.length() + j.length()));
//            System.out.println("phi : " + psi);

//            int opening = indx + PSI_SIZE + i.length() + j.length() + psi.length();
                int opening = fistEffectiveCharacter + 2 + i.length() + j.length();
                String phi = s.substring(opening, getParenthesisIndex(s, opening));
//            System.out.println("psi : " + phi);
                result = s.substring(0, indx)
                        + Dt(i, j, phi)
                        + s.substring(fistEffectiveCharacter + 3 + i.length() + j.length()
                        + phi.length());
                current = indx + 1;
                if (result != "")
                    s = result;
            }

        }
        if (result == "") return s;
        /*if (correctParenthese(result)){
            JOptionPane.showConfirmDialog(null,"Correct Formulae Detected, Parsing ...","Status",JOptionPane.INFORMATION_MESSAGE);
        }*/
        return result;
    }

    public String Dt(String i, String j, String phi) {
        String group = preprocessGroup(i);
        return String.format("AX( alpha-%s-D-%s -> AX(%s) )", group, j, phi);
//        return "AX( alpha-i)";
    }

    public String removeWhiteSpace(String h) {
        StringBuilder st = new StringBuilder();
        for (int i = 0; i < h.length(); i++) {
            char c = h.charAt(i);
            if (c != ' ')
                st.append(c);
        }
        return st.toString();
    }

    public static void main(String[] args) throws ParenthesisException {
//        String input = "Tp(i,j,psi,phi)";
//        String input = "E[i->j U psi ]";
//        String input = "E[i->j U E[p U !q] ]";
//        String input = "EG( E[i->j U E[p U !q] ] -> q )";
//        String input = "T(i,j,phi)";
//        String input = "T(i,j,T(k,n,!q AND (t -> p)))";
//        String input = "Pt( i, j, ! phi -> q)";
        //
//        String input = "Et(  { i , j , k } ,   m , !phi -> q )";
//        String input = "Et(i,m,!phi -> q)";
//        String input = "EF DT({Patia_4, Patia_2}, Physi_1, Mammo_Refered) ;";
        String input = "EF PT({Patia_1, Patia_2}, Manuf_2, Mammo_Refered);";
//        String input = "Dt(i,m, Et(j,k,!q) -> p)";
//        String input = "T(k,n,!q & (t -> p))";
//        String input = "EX(pANDEX(psi,phiOREX(!q))EX((not)))";
//        String input = "EX(p & EX(psi -> phi) OR EX(q) )";
        BranchingCommToSMV one = new BranchingCommToSMV();
//        one.init(input);
        String res = one.action(input);
         System.out.println(res);
//        String temp = "{    Patia_8, Patia_4       }";
//        System.out.println(one.preprocessGroup(one.removeWhiteSpace(temp)));
//        System.out.println(one.EUntil(input));
//        String st = one.parseEX(input);
//        System.out.println(st);
    }

}
