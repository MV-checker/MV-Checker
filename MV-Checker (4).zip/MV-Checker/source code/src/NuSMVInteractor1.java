import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;

public class NuSMVInteractor1 {
	static final String nusmvCommands = "nusmv";
    static final String nusmvParameters = "-v 1";
    static final String pars = "-r";
    static final String modelFileSaved = "C:\\JTL\\scal.out";


    public NuSMVInteractor1() {
    }

    public static String runNuSMVModel() throws IOException {

        String modelOutput = "";
        final Vector<String> command = new Vector<String>();
        command.add(nusmvCommands);
        final StringTokenizer tokens = new StringTokenizer(
                nusmvParameters, " ");
        while (tokens.hasMoreTokens()) {
            command.add(tokens.nextToken());
        }

        command.add(pars);
        command.add(modelFileSaved);
        final ProcessBuilder builder = new ProcessBuilder(command);
        builder.redirectErrorStream(true);
        final Process process = builder.start();
        final InputStream lsOut = process.getInputStream();
        final InputStreamReader r = new InputStreamReader(lsOut);
        final BufferedReader in = new BufferedReader(r);
        String line;
        while ((line = in.readLine()) != null) {
            modelOutput = String.valueOf(modelOutput) + line + "\n";
        }

        modelOutput = decodeIntoTextFormat(modelOutput);

        return modelOutput;

    }
    // this method transforms the bites returned by nusmv into string
    private static String decodeIntoTextFormat(String modelOutput) {
        return NusmvWorker1.decodeBits(modelOutput);
    }


}
