import java.util.*;

public class Modulesmv {
    // module name
    String Name;
    // init state !
    String init;
    // the entire transition part for this agent
    String eval;
    // the name of the variable that's a state one
    String state;
    int stateVariableIndex;
    // indice de la variable qui represente les states !
    int states;
    String abrev;
    // list of all possible variables : each one contains the name and then all values divided by spaces
    Vector<String> vars;
    ArrayList<String> actions;
    // other agents to add in the variable
    Set<String> other;
    Set<String> otherAbrev;
    // transitions
    boolean trans[][];
    boolean validated;
    // state values : as in just strings
    ArrayList<String> stateVals;
    // arraylist of all states
    ArrayList<State> allstates;
    // set of shared
    Set<String> shared;
    // set of unshared
    Set<String> unshared;
    Map<String, String> sharedWith;

    public Modulesmv() {
        validated = false;
        allstates = new ArrayList<State>();
        vars = new Vector<String>();
        actions = new ArrayList<String>();
        other = new TreeSet<String>();
        otherAbrev = new TreeSet<String>();
        shared = new TreeSet<String>();
        unshared = new TreeSet<String>();
        states = -1;
        state = "";
        eval = "";
        stateVariableIndex = -1;
        trans = new boolean[100][100];
        for (int i = 0; i < 100; ++i) {
            for (int j = 0; j < 100; ++j) {
                trans[i][j] = false;
            }
        }
        stateVals = new ArrayList<String>();       
        sharedWith = new HashMap<String, String>();
    }

    public void ValidateStates() {
        if (!validated) {
            String[] h = vars.get(states).split(" ");
            
            for (int i = 1; i < h.length; i++) {
                if (h[i].length() != 0) {
                    stateVals.add(h[i]);
                    State s = new State(h[i]);
                    allstates.add(s);
                    
                }
            }
            validated = true;
        }

    }

    public void setTrans(String src, String dest) {
        int i = stateVals.indexOf(src);
        int j = stateVals.indexOf(dest);
        trans[i][j] = true;
    }

    public void addOther(String f) {
        other.add(f);

    }

    public String getActions() {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < actions.size(); i++) {
            if (i == 0) {
                b.append(actions.get(0) + "");
            } else {
                b.append("," + actions.get(i) + "");
            }
        }
        b.append("};\n");
        return b.toString();
    }

    public String getVars() {
        StringBuilder b = new StringBuilder();
        boolean first = true;
        for (String s : stateVals) {
            if (s != "") {
                if (first) {
                    b.append(s + " ");
                    first = false;
                } else {
                    b.append("," + s + " ");
                    
                }

            }

        }
        b.append("};\n");
        
        return b.toString();
        
    }

    public String getOthers() {
        StringBuilder b = new StringBuilder();
        int i = 0;
        for (String h : other) {
            if (i == 0) {
                b.append(h + "-action");
            } else {
                b.append("," + h + "-action");
            }
            i++;
        }
        b.append(")\n");
        return b.toString();
    }

    public String getOther() {
        StringBuilder b = new StringBuilder();
        int i = 0;
        for (String h : otherAbrev) {
            if (i == 0) {
                b.append(h + ".action");
            } else {
                b.append("," + h + ".action");
            }
            i++;
        }
        b.append(");\n");
        return b.toString();
    }


    public String getName() {
        return Name;
    }


    public void setName(String name) {
        Name = name;
    }


    public int getI() {
        return stateVariableIndex;
    }


    public void setI(int i) {
    	
    	 
        this.stateVariableIndex = i;
        if (Name.length() > 3) {
            abrev = Name.substring(0, 3) + i;                        
        } else {
            abrev = Name + i; 
            
        }
       // abrev = abrev +"Dis2"; her 
      
        
      // System.out.println(Name);
      //  System.out.println(abrev);
         
        ////////////
        
      
    }


    public String getAbrev() {
        return abrev;
    }


    public void setAbrev(String abrev) {
        this.abrev = abrev;
    }

    public void addVar(String s) {
        vars.add(s);
    }

    public void addAction(String act) {
        actions.add(act);
    }

    public boolean removeAction(String t) {
        return actions.remove(t);
    }

    public void setState(String st) {
        int size = st.length();
        int k = 0;
        for (String s : vars) {
            if (s.substring(0, size).equals(st)) {
                states = k;
                state = st;
                break;
            }
            k++;
        }
    }


    public String getInit() {
        return init;
    }


    public void setInit(String init) {
        this.init = init;
    }


    public String getEval() {
        return eval;
    }

    // appends data
    public void setEval(String eval) {
        this.eval = this.eval + eval;
    }


    public String getState() {
        return state;
    }

    public State getByName(String name) {
        for (State s : allstates) {
            if (s.getName().equals(name)) {
                return s;
            }
        }
        return null;
    }

    public void findShared(Module n) {
        for (String s : this.vars) {
            for (String ss : n.vars) {
                String[] nameA = s.split(" ");
                String[] nameB = ss.split(" ");
                if (nameA[0].equals(nameB[0])) {

                    sharedWith.put(n.getName(), nameA[0]);
                    n.sharedWith.put(n.getName(), nameA[0]);
                }
            }

        }
    }

    public void setup() {
        
        char[] hh1 = new char[]{69,110,118,105,114,111,110,109,101,110,116,};
        char[] hh2 = new char[]{69,110,118,105,114,111,110,109,101,110,116,95,};
         char[] hh3 = new char[]{66,117,121,114,95,};
        char[] hh4 = new char[]{83,101,108,108,101,114,95,};
        char[] hh5 = new char[]{77,111,114,116,83,95,};
        char[] hh6 = new char[]{66,66,117,121,95};
        char[] hh7 = new char[]{66,83,101,108,108,95};
        char[] hh8 = new char[]{66,70,109,95,};
        char[] hh9 = new char[]{83,109,67,111,110,116,95,};
        char[] hh10 = new char[]{84,83,101,97,114,99,104,95};
        char[] hh11 = new char[]{77,117,110,105,95};
               
       String e = HashingData.decodeFromBits(hh1);
       String fe = HashingData.decodeFromBits(hh2);
       String p = HashingData.decodeFromBits(hh3);
       String fq = HashingData.decodeFromBits(hh4);
       String fr = HashingData.decodeFromBits(hh5);
       String fp = HashingData.decodeFromBits(hh6);
       String fg = HashingData.decodeFromBits(hh7);
       String fgg = HashingData.decodeFromBits(hh8);
       String fg9 = HashingData.decodeFromBits(hh9);
       String fg10 = HashingData.decodeFromBits(hh10);
       String fg11 = HashingData.decodeFromBits(hh11);
      
      

  
        
                  
       int[] from = new int[]{3, 3, 3, 3, 4, 4, 4, 5, 5, 6, 13, 7, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 10, 10, 11};
        int[] to = new int[]{4, 5, 6, 7, 5, 6, 7, 6, 7, 7, 15, 8, 9, 10, 11, 12, 9, 10, 11, 12, 10, 11, 12, 11, 12, 12, 12, 12, 12};

        int [] sr = new int[]{2, 2, 3};
        int [] ds = new int[]{3, 4, 4};

        String[] agents = new String[10];
        agents[0] = HashingData.decodeFromBits(new char[]{101}); 
        agents[1] = HashingData.decodeFromBits(new char[]{66,117}); 
        agents[2] = HashingData.decodeFromBits(new char[]{115,101});        
        agents[3] = HashingData.decodeFromBits(new char[]{77,111});        
        agents[4] = HashingData.decodeFromBits(new char[]{66,98});       
        agents[5] = HashingData.decodeFromBits(new char[]{83,98});
        agents[6] = HashingData.decodeFromBits(new char[]{66,102});  
        agents[7] = HashingData.decodeFromBits(new char[]{83,109});
        agents[8] = HashingData.decodeFromBits(new char[]{84,115});
        agents[9] = HashingData.decodeFromBits(new char[]{77,110});
        
        String[] ag = new String[]{"p", "s", "b"};
       
 
        if (Name != null && !Name.isEmpty() && Name.length() >= 3 && Name.startsWith(fe)) {
            String n = Name.substring(Name.length() - 1);
            if (Name.length() > fe.length()+1) {
                n = Name.substring(Name.length() - 2);
            }
            String list[] = eval.split("\n");
            int indx = 0;
            if (list.length > 2) {
                int k = list.length - 2;
                StringBuilder st = new StringBuilder();
                for (int j = 0; j < k; j++) {
                    st.append(list[j] + "\n");
                }
                for (int i = 0; i < from.length; i++) {
                    stateVals.add(agents[indx] + from[i] + "_" + to[i]);
                    char[] f1 = new char[]{97,99,99,95,37,100,95,37,100,};
                    char[] f2 = new char[]{97,99,99,95,99,95,37,100,95,37,100,};
                    char[] f3 = new char[]{45,45,32,78,101,119,32,65,99,99,101,115,115,105,98,105,108,105,116,121,32,116,114,97,110,115,105,116,105,111,110,115,10,};
                  
                    char[] f4 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,
                    		32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,95,37,100,59,10,};
                    char[] f5 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,95,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,59,10,};
 
                    String h1 = new String(f1);
                    String h2 = new String(f2);
                    String h3 = new String(f3);
                    String h4 = new String(f4);
                    String h5 = new String(f5);
               
                    String act = String.format(h1, from[i], to[i]);
                    String sact = String.format(h2, from[i], to[i]);
                    actions.add(act);
                    actions.add(sact);
                    if (i == 0) {
                        st.append(h3);
                    }
                    st.append(String.format(h4, agents[indx], from[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], agents[indx], from[i], to[i]));
                    st.append(String.format(h5, agents[indx], from[i], to[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], agents[indx], to[i]));
                }
                eval = st.toString() + "\n" + list[k] + "\n" + list[k + 1] + "\n";
               
            }
             
            

        } else if (Name != null && !Name.isEmpty() && Name.length() >= 3 && Name.startsWith(p)) {
            String n = Name.substring(Name.length() - 1);
            if (Name.length() > p.length()+1) {
                n = Name.substring(Name.length() - 2);
            }
            String list[] = eval.split("\n");
            int indx = 1;
            if (list.length > 2) {
                int k = list.length - 2;
                StringBuilder st = new StringBuilder();
                for (int j = 0; j < k; j++) {
                    st.append(list[j] + "\n");
                }
                for (int i = 0; i < from.length; i++) {
                    stateVals.add(agents[indx] + from[i] + "_" + to[i]);
                    char[] f1 = new char[]{97,99,99,95,37,100,95,37,100,};
                    char[] f2 = new char[]{97,99,99,95,99,95,37,100,95,37,100,};
                    char[] f3 = new char[]{45,45,32,78,101,119,32,65,99,99,101,115,115,105,98,105,108,105,116,121,32,116,114,97,110,115,105,116,105,111,110,115,10,};
                    char[] f4 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,
                    		32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,95,37,100,59,10,};
                    
                    
                    char[] f5 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,95,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,59,10,};

                    String h1 = new String(f1);
                    String h2 = new String(f2);
                    String h3 = new String(f3);
                    String h4 = new String(f4);
                    String h5 = new String(f5);
                         String act = String.format(h1, from[i], to[i]);
                    String sact = String.format(h2, from[i], to[i]);
                    actions.add(act);
                    actions.add(sact);
                    if (i == 0) {
                        st.append(h3);
                    }
                    st.append(String.format(h4, agents[indx], from[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],  agents[indx], from[i], to[i]));
                    st.append(String.format(h5, agents[indx], from[i], to[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], agents[indx], to[i]));
                }
                eval = st.toString() + "\n" + list[k] + "\n" + list[k + 1] + "\n";             
            }
            

        } else if (Name != null && !Name.isEmpty() && Name.length() >= 3 && Name.startsWith(fq)) {
        //	System.out.println(fq);
            String n = Name.substring(Name.length() - 1);
            if (Name.length() > fq.length()+1) {
                n = Name.substring(Name.length() - 2);
            }
            String list[] = eval.split("\n");
            int indx = 2;
            if (list.length > 2) {
                int k = list.length - 2;
                StringBuilder st = new StringBuilder();
                for (int j = 0; j < k; j++) {
                    st.append(list[j] + "\n");
                }
                for (int i = 0; i < from.length; i++) {
                    stateVals.add(agents[indx] + from[i] + "_" + to[i]);

                    char[] f1 = new char[]{97,99,99,95,37,100,95,37,100,};
                    char[] f2 = new char[]{97,99,99,95,99,95,37,100,95,37,100,};
                    char[] f3 = new char[]{45,45,32,78,101,119,32,65,99,99,101,115,115,105,98,105,108,105,116,121,32,116,114,97,110,115,105,116,105,111,110,115,10,};
                    char[] f4 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,
                    		32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,95,37,100,59,10,};                  
                    
                    char[] f5 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,95,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,59,10,};

                    String h1 = new String(f1);
                    String h2 = new String(f2);
                    String h3 = new String(f3);
                    String h4 = new String(f4);
                    String h5 = new String(f5);
                
                    String act = String.format(h1, from[i], to[i]);
                    String sact = String.format(h2, from[i], to[i]);
                    actions.add(act);
                    actions.add(sact);
                    if (i == 0) st.append(h3);
                    st.append(String.format(h4, agents[indx], from[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],  agents[indx], from[i], to[i]));
                    st.append(String.format(h5, agents[indx], from[i], to[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], agents[indx], to[i]));
                }
                eval = st.toString() + "\n" + list[k] + "\n" + list[k + 1] + "\n";
            }
          
            
        } else if (Name != null && !Name.isEmpty() && Name.length() >= 3 && Name.startsWith(fr)) {
        
            String n = Name.substring(Name.length() - 1);
            if (Name.length() > fr.length()+1) {
                n = Name.substring(Name.length() - 2);
            }
            String list[] = eval.split("\n");
            int indx = 3;
            if (list.length > 2) {
                int k = list.length - 2;
                StringBuilder st = new StringBuilder();
                for (int j = 0; j < k; j++) {
                    st.append(list[j] + "\n");
                }
                for (int i = 0; i < from.length; i++) {
                    stateVals.add(agents[indx] + from[i] + "_" + to[i]);
                    char[] f1 = new char[]{97,99,99,95,37,100,95,37,100,};
                    char[] f2 = new char[]{97,99,99,95,99,95,37,100,95,37,100,};
                    char[] f3 = new char[]{45,45,32,78,101,119,32,65,99,99,101,115,115,105,98,105,108,105,116,121,32,116,114,97,110,115,105,116,105,111,110,115,10,};
                    char[] f4 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,
                    		32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,95,37,100,59,10,};                                        
                    char[] f5 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,95,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,59,10,};
                    String h1 = new String(f1);
                    String h2 = new String(f2);
                    String h3 = new String(f3);
                    String h4 = new String(f4);
                    String h5 = new String(f5);
                  
                    String act = String.format(h1, from[i], to[i]);
                    String sact = String.format(h2, from[i], to[i]);
                    actions.add(act);
                    actions.add(sact);
                    //3
                    if (i == 0) {
                        st.append(h3);
                    }
                    st.append(String.format(h4, agents[indx], from[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],  agents[indx], from[i], to[i]));
                    st.append(String.format(h5, agents[indx], from[i], to[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], agents[indx], to[i]));
                }
                eval = st.toString() + "\n" + list[k] + "\n" + list[k + 1] + "\n";
            }           
        } else if (Name != null && !Name.isEmpty() && Name.length() >= 3 && Name.startsWith(fp)) {
       // 	System.out.println(fp);
            String n = Name.substring(Name.length() - 1);
            if (Name.length() > fp.length()+1) {
                n = Name.substring(Name.length() - 2);
            }
            String list[] = eval.split("\n");
            int indx = 4;
            if (list.length > 2) {
                int k = list.length - 2;
                StringBuilder st = new StringBuilder();
                for (int j = 0; j < k; j++) {
                    st.append(list[j] + "\n");
                }
                for (int i = 0; i < from.length; i++) {
                    stateVals.add(agents[indx] + from[i] + "_" + to[i]);

                    char[] f1 = new char[]{97,99,99,95,37,100,95,37,100,};
                    char[] f2 = new char[]{97,99,99,95,99,95,37,100,95,37,100,};
                    char[] f3 = new char[]{45,45,32,78,101,119,32,65,99,99,101,115,115,105,98,105,108,105,116,121,32,116,114,97,110,115,105,116,105,111,110,115,10,};
                    char[] f4 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,
                    		32,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,95,37,100,59,10,};                                         
                    char[] f5 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,95,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,59,10,};
                    String h1 = new String(f1);
                    String h2 = new String(f2);
                    String h3 = new String(f3);
                    String h4 = new String(f4);
                    String h5 = new String(f5);
                  
                    String act = String.format(h1, from[i], to[i]);
                    String sact = String.format(h2, from[i], to[i]);
                    actions.add(act);
                    actions.add(sact);
                    if (i == 0 ) {
                        st.append(h3);
                    }
                    st.append(String.format(h4, agents[indx], from[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],  agents[indx], from[i], to[i]));
                    st.append(String.format(h5, agents[indx], from[i], to[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], agents[indx], to[i]));
                }
                eval = st.toString() + "\n" + list[k] + "\n" + list[k + 1] + "\n";
            }           
        } else if (Name != null && !Name.isEmpty() && Name.length() >= 3 && Name.startsWith(fg)) {
            String n = Name.substring(Name.length() - 1);
            if (Name.length() > fg.length()+1) {
                n = Name.substring(Name.length() - 2);
            }
            String list[] = eval.split("\n");
            int indx = 5;
            if (list.length > 2) {
                int k = list.length - 2;
                StringBuilder st = new StringBuilder();
                for (int j = 0; j < k; j++) {
                    st.append(list[j] + "\n");
                }
                for (int i = 0; i < from.length; i++) {

                    char[] f1 = new char[]{97,99,99,95,37,100,95,37,100,};
                    char[] f2 = new char[]{97,99,99,95,99,95,37,100,95,37,100,};
                    char[] f3 = new char[]{45,45,32,78,101,119,32,65,99,99,101,115,115,105,98,105,108,105,116,121,32,116,114,97,110,115,105,116,105,111,110,115,10,};
                    char[] f4 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,
                    		32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,95,37,100,59,10,};
                     char[] f5 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,95,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,59,10,};
                    String h1 = new String(f1);
                    String h2 = new String(f2);
                    String h3 = new String(f3);
                    String h4 = new String(f4);
                    String h5 = new String(f5);                   
                    stateVals.add(agents[indx] + from[i] + "_" + to[i]);
                    String act = String.format(h1, from[i], to[i]);
                    String sact = String.format(h2, from[i], to[i]);
                    actions.add(act);
                    actions.add(sact);                  
                    if (i == 0) {
                        st.append(h3);
                    }
                    st.append(String.format(h4, agents[indx], from[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],  agents[indx], from[i], to[i]));
                    st.append(String.format(h5, agents[indx], from[i], to[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], agents[indx], to[i]));
                }
                eval = st.toString() + "\n" + list[k] + "\n" + list[k + 1] + "\n";
            }
            //for Rg smart C
          //  System.out.println(eval); 

        } else if  (Name != null && !Name.isEmpty() && Name.length() >= 3 && Name.startsWith(fgg)) {
            String n = Name.substring(Name.length() - 1);
            if (Name.length() > fgg.length()+1) {
                n = Name.substring(Name.length() - 2);
            }
            String list[] = eval.split("\n");
            int indx = 6;
            if (list.length > 2) {
                int k = list.length - 2;
                StringBuilder st = new StringBuilder();
                for (int j = 0; j < k; j++) {
                    st.append(list[j] + "\n");
                }
                for (int i = 0; i < from.length; i++) {

                    char[] f1 = new char[]{97,99,99,95,37,100,95,37,100,};
                    char[] f2 = new char[]{97,99,99,95,99,95,37,100,95,37,100,};
                    char[] f3 = new char[]{45,45,32,78,101,119,32,65,99,99,101,115,115,105,98,105,108,105,116,121,32,116,114,97,110,115,105,116,105,111,110,115,10,};
                    char[] f4 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,
                    		32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,95,37,100,59,10,};
                     char[] f5 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,95,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,59,10,}; 
                    String h1 = new String(f1);
                    String h2 = new String(f2);
                    String h3 = new String(f3);
                    String h4 = new String(f4);
                    String h5 = new String(f5);
                    stateVals.add(agents[indx] + from[i] + "_" + to[i]);
                    String act = String.format(h1, from[i], to[i]);
                    String sact = String.format(h2, from[i], to[i]);
                    actions.add(act);
                    actions.add(sact);
                    //3
                    if (i == 0) {
                        st.append(h3);
                    }
                    st.append(String.format(h4, agents[indx], from[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],  agents[indx], from[i], to[i]));
                    st.append(String.format(h5, agents[indx], from[i], to[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], agents[indx], to[i]));
                }
                eval = st.toString() + "\n" + list[k] + "\n" + list[k + 1] + "\n";
            }
        } else if (Name != null && !Name.isEmpty() && Name.length() >= 3 && Name.startsWith(fg9)) {
            String n = Name.substring(Name.length() - 1);
            if (Name.length() > fg9.length()+1) {
                n = Name.substring(Name.length() - 2);
            }
            String list[] = eval.split("\n");
            int indx = 7;
            if (list.length > 2) {
                int k = list.length - 2;
                StringBuilder st = new StringBuilder();
                for (int j = 0; j < k; j++) {
                    st.append(list[j] + "\n");
                }
                for (int i = 0; i < from.length; i++) {

                    char[] f1 = new char[]{97,99,99,95,37,100,95,37,100,};
                    char[] f2 = new char[]{97,99,99,95,99,95,37,100,95,37,100,};
                    char[] f3 = new char[]{45,45,32,78,101,119,32,65,99,99,101,115,115,105,98,105,108,105,116,121,32,116,114,97,110,115,105,116,105,111,110,115,10,};
                    char[] f4 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,
                    		32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,95,37,100,59,10,};
                    char[] f5 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,95,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,59,10,}; 
                    String h1 = new String(f1);
                    String h2 = new String(f2);
                    String h3 = new String(f3);
                    String h4 = new String(f4);
                    String h5 = new String(f5);
                    stateVals.add(agents[indx] + from[i] + "_" + to[i]);
                    String act = String.format(h1, from[i], to[i]);
                    String sact = String.format(h2, from[i], to[i]);
                    actions.add(act);
                    actions.add(sact);
                    //3
                    if (i == 0) {
                        st.append(h3);
                    }
                    st.append(String.format(h4, agents[indx], from[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],  agents[indx], from[i], to[i]));
                    st.append(String.format(h5, agents[indx], from[i], to[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], agents[indx], to[i]));
                }   
                eval = st.toString() + "\n" + list[k] + "\n" + list[k + 1] + "\n";
            }
        } else if (Name != null && !Name.isEmpty() && Name.length() >= 3 && Name.startsWith(fg10)) {
            String n = Name.substring(Name.length() - 1);
            if (Name.length() > fg10.length()+1) {
                n = Name.substring(Name.length() - 2);
            }
            String list[] = eval.split("\n");
            int indx = 8;
            if (list.length > 2) {
                int k = list.length - 2;
                StringBuilder st = new StringBuilder();
                for (int j = 0; j < k; j++) {
                    st.append(list[j] + "\n");
                }
                for (int i = 0; i < from.length; i++) {

                    char[] f1 = new char[]{97,99,99,95,37,100,95,37,100,};
                    char[] f2 = new char[]{97,99,99,95,99,95,37,100,95,37,100,};
                    char[] f3 = new char[]{45,45,32,78,101,119,32,65,99,99,101,115,115,105,98,105,108,105,116,121,32,116,114,97,110,115,105,116,105,111,110,115,10,};
                    char[] f4 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,
                    		32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,95,37,100,59,10,};
                    char[] f5 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,95,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,32,38,32,77,117,110,105,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,41,32,58,32,37,115,37,100,59,10,};
 
                    String h1 = new String(f1);
                    String h2 = new String(f2);
                    String h3 = new String(f3);
                    String h4 = new String(f4);
                    String h5 = new String(f5);
                    stateVals.add(agents[indx] + from[i] + "_" + to[i]);
                    String act = String.format(h1, from[i], to[i]);
                    String sact = String.format(h2, from[i], to[i]);
                    actions.add(act);
                    actions.add(sact);
                    //3
                    if (i == 0) {
                        st.append(h3);
                    }
                    st.append(String.format(h4, agents[indx], from[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],  agents[indx], from[i], to[i]));
                    st.append(String.format(h5, agents[indx], from[i], to[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], agents[indx], to[i]));
                }   
                eval = st.toString() + "\n" + list[k] + "\n" + list[k + 1] + "\n";
            }
        } else if (Name != null && !Name.isEmpty() && Name.length() >= 3 && Name.startsWith(fg11)) {
            String n = Name.substring(Name.length() - 1);
            if (Name.length() > fg11.length()+1) {
                n = Name.substring(Name.length() - 2);
            }
            String list[] = eval.split("\n");
            int indx = 9;
            if (list.length > 2) {
                int k = list.length - 2;
                StringBuilder st = new StringBuilder();
                for (int j = 0; j < k; j++) {
                    st.append(list[j] + "\n");
                }
                for (int i = 0; i < from.length; i++) {

                    char[] f1 = new char[]{97,99,99,95,37,100,95,37,100,};
                    char[] f2 = new char[]{97,99,99,95,99,95,37,100,95,37,100,};
                    char[] f3 = new char[]{45,45,32,78,101,119,32,65,99,99,101,115,115,105,98,105,108,105,116,121,32,116,114,97,110,115,105,116,105,111,110,115,10,};
                    char[] f4 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,
                    		32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,41,32,58,32,37,115,37,100,95,37,100,59,10,};
                    char[] f5 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,95,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,77,111,114,116,83,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,117,121,114,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,70,109,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,83,109,67,111,110,116,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,66,117,121,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,83,101,108,108,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,84,83,101,97,114,99,104,95,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,41,32,58,32,37,115,37,100,59,10,};
 
                    String h1 = new String(f1);
                    String h2 = new String(f2);
                    String h3 = new String(f3);
                    String h4 = new String(f4);
                    String h5 = new String(f5);
                    stateVals.add(agents[indx] + from[i] + "_" + to[i]);
                    String act = String.format(h1, from[i], to[i]);
                    String sact = String.format(h2, from[i], to[i]);
                    actions.add(act);
                    actions.add(sact);
                    //3
                    if (i == 0) {
                        st.append(h3);
                    }
                    st.append(String.format(h4, agents[indx], from[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],  agents[indx], from[i], to[i]));
                    st.append(String.format(h5, agents[indx], from[i], to[i], from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], n, from[i], to[i],n, from[i], to[i], n, from[i], to[i], n, from[i], to[i], agents[indx], to[i]));
                }   
                eval = st.toString() + "\n" + list[k] + "\n" + list[k + 1] + "\n";
                //System.out.println(eval);
            }
        } else if 
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
  //old sys      
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////       
        (Name != null && !Name.isEmpty() && Name.length() >= 3 && Name.startsWith(e)) {

            char[] h1 = new char[]{37,115,37,100,95,37,100,};
            char[] h2 = new char[]{97,99,99,95,37,100,95,37,100,};
            char[] h3 = new char[]{97,99,99,95,99,95,37,100,95,37,100,};
            char[] h4 = new char[]{45,45,32,78,101,119,32,65,99,99,101,115,115,105,98,105,108,105,116,121,32,116,114,97,110,115,105,116,105,111,110,115,10};
            char[] h5 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,66,117,121,101,114,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,38,32,83,101,108,108,101,114,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,37,100,95,37,100,32,32,41,32,58,32,37,115,37,100,95,37,100,59,10,};
            char[] h6 = new char[]{40,32,115,116,97,116,101,32,61,32,37,115,37,100,95,37,100,32,38,32,83,101,108,108,101,114,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,66,117,121,101,114,37,115,45,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,38,32,97,99,116,105,111,110,32,61,32,97,99,99,95,99,95,37,100,95,37,100,32,41,32,58,32,37,115,37,100,32,59,10,};
            char[] h7 = new char[]{37,115,10,37,115,10,37,115,10,};

            String t1 = new String(h1);
            String t2 = new String(h2);
            String t3 = new String(h3);
            String t4 = new String(h4);
            String t5 = new String(h5);
            String t6 = new String(h6);
            String t7 = new String(h7);
          
            String n = Name.substring(Name.length() - 1);
            if (Name.length() > e.length()+1) {
                n = Name.substring(Name.length() - 2);
            }
            String list[] = eval.split("\n");
            int indx = 0;
            if (list.length > 2) {
                int k = list.length - 2;
                StringBuilder st = new StringBuilder();
                for (int j = 0; j < k; j++) {
                    st.append(list[j] + "\n");
                }
                for (int i = 0; i < sr.length; i++) {

                    stateVals.add(String.format(t1, ag[indx], sr[i], ds[i]));
                    String act = String.format(t2, sr[i], ds[i]);
                    String sact = String.format(t3, sr[i], ds[i]);
                    actions.add(act);
                    actions.add(sact);
                    if (i == 0 ) {
                        st.append(t4);
                    }
                    st.append(String.format(t5, ag[indx], sr[i], sr[i], ds[i], n, sr[i], ds[i], n, sr[i], ds[i], ag[indx], sr[i], ds[i]));
                    st.append(String.format(t6, ag[indx], sr[i], ds[i], n, sr[i], ds[i], n, sr[i], ds[i], sr[i], ds[i], ag[indx], ds[i]));
                }
                eval = String.format(t7, st.toString(), list[k], list[k + 1]);
                 
            }
             
        }
    }

	public void findShared(Modulesmv n) {
		// TODO Auto-generated method stub
		
	}
    
}
